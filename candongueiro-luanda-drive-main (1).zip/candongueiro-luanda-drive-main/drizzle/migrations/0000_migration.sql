
-- PROFILES
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL DEFAULT 'Utilizador',
  user_type text NOT NULL DEFAULT 'passageiro',
  phone text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.profiles TO anon;
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles readable" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "own profile insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid());
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid());

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name, user_type)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email,'@',1), 'Utilizador'),
    CASE WHEN NEW.raw_user_meta_data->>'user_type' = 'taxista' THEN 'taxista' ELSE 'passageiro' END
  ) ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ROAD REPORTS
CREATE TABLE public.road_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  author_name text NOT NULL DEFAULT 'Anónimo',
  author_type text NOT NULL DEFAULT 'passageiro',
  type text NOT NULL DEFAULT 'transito',
  location text NOT NULL,
  description text,
  photo_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.road_reports TO anon;
GRANT SELECT, INSERT, DELETE ON public.road_reports TO authenticated;
GRANT ALL ON public.road_reports TO service_role;
ALTER TABLE public.road_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reports readable" ON public.road_reports FOR SELECT USING (true);
CREATE POLICY "reports insert own" ON public.road_reports FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "reports delete own" ON public.road_reports FOR DELETE TO authenticated USING (user_id = auth.uid());

CREATE TABLE public.report_votes (
  report_id uuid NOT NULL REFERENCES public.road_reports(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  vote text NOT NULL CHECK (vote IN ('confirm','dismiss')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (report_id, user_id)
);
GRANT SELECT ON public.report_votes TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.report_votes TO authenticated;
GRANT ALL ON public.report_votes TO service_role;
ALTER TABLE public.report_votes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "votes readable" ON public.report_votes FOR SELECT USING (true);
CREATE POLICY "votes insert own" ON public.report_votes FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "votes update own" ON public.report_votes FOR UPDATE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "votes delete own" ON public.report_votes FOR DELETE TO authenticated USING (user_id = auth.uid());

-- GROUPS
CREATE TABLE public.groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  owner_name text NOT NULL DEFAULT 'Utilizador',
  audience text NOT NULL DEFAULT 'passageiro' CHECK (audience IN ('taxista','passageiro')),
  kind text NOT NULL CHECK (kind IN ('vaquinha','free_ride','strike','notice','support','ride_pool')),
  title text NOT NULL,
  description text,
  zone text,
  departure_zone text,
  destination text,
  travel_at timestamptz,
  seats integer,
  goal_kz integer,
  raised_kz integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','full','closed')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.groups TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.groups TO authenticated;
GRANT ALL ON public.groups TO service_role;
ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.group_members (
  group_id uuid NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  member_name text NOT NULL DEFAULT 'Utilizador',
  role text NOT NULL DEFAULT 'member' CHECK (role IN ('admin','member')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (group_id, user_id)
);
GRANT SELECT ON public.group_members TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.group_members TO authenticated;
GRANT ALL ON public.group_members TO service_role;
ALTER TABLE public.group_members ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_group_admin(_group_id uuid, _user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.group_members WHERE group_id=_group_id AND user_id=_user_id AND role='admin')
$$;
CREATE OR REPLACE FUNCTION public.is_group_member(_group_id uuid, _user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.group_members WHERE group_id=_group_id AND user_id=_user_id)
$$;

CREATE POLICY "groups readable" ON public.groups FOR SELECT USING (true);
CREATE POLICY "groups insert own" ON public.groups FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "groups update admin" ON public.groups FOR UPDATE TO authenticated USING (public.is_group_admin(id, auth.uid()));
CREATE POLICY "groups delete admin" ON public.groups FOR DELETE TO authenticated USING (public.is_group_admin(id, auth.uid()));

CREATE POLICY "members readable" ON public.group_members FOR SELECT USING (true);
CREATE POLICY "members join self" ON public.group_members FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND role = 'member');
CREATE POLICY "members update admin" ON public.group_members FOR UPDATE TO authenticated USING (public.is_group_admin(group_id, auth.uid()));
CREATE POLICY "members leave or admin remove" ON public.group_members FOR DELETE TO authenticated USING (user_id = auth.uid() OR public.is_group_admin(group_id, auth.uid()));

CREATE OR REPLACE FUNCTION public.add_group_owner()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.group_members (group_id, user_id, member_name, role) VALUES (NEW.id, NEW.owner_id, NEW.owner_name, 'admin');
  RETURN NEW;
END $$;
CREATE TRIGGER groups_add_owner AFTER INSERT ON public.groups FOR EACH ROW EXECUTE FUNCTION public.add_group_owner();

CREATE OR REPLACE FUNCTION public.update_pool_status()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE gid uuid; cnt int; g record;
BEGIN
  gid := COALESCE(NEW.group_id, OLD.group_id);
  SELECT * INTO g FROM public.groups WHERE id = gid;
  IF g.kind = 'ride_pool' AND g.seats IS NOT NULL AND g.status <> 'closed' THEN
    SELECT count(*) INTO cnt FROM public.group_members WHERE group_id = gid;
    UPDATE public.groups SET status = CASE WHEN cnt >= g.seats THEN 'full' ELSE 'open' END WHERE id = gid;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER members_pool_status AFTER INSERT OR DELETE ON public.group_members FOR EACH ROW EXECUTE FUNCTION public.update_pool_status();

CREATE OR REPLACE FUNCTION public.contribute_vaquinha(_group_id uuid, _amount integer)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF _amount <= 0 OR _amount > 10000000 THEN RAISE EXCEPTION 'invalid amount'; END IF;
  UPDATE public.groups SET raised_kz = raised_kz + _amount WHERE id = _group_id AND kind = 'vaquinha';
END $$;
GRANT EXECUTE ON FUNCTION public.contribute_vaquinha(uuid, integer) TO authenticated;

-- GROUP POSTS
CREATE TABLE public.group_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  author_name text NOT NULL DEFAULT 'Utilizador',
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.group_posts TO anon;
GRANT SELECT, INSERT, DELETE ON public.group_posts TO authenticated;
GRANT ALL ON public.group_posts TO service_role;
ALTER TABLE public.group_posts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "posts readable" ON public.group_posts FOR SELECT USING (true);
CREATE POLICY "posts insert member" ON public.group_posts FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND public.is_group_member(group_id, auth.uid()));
CREATE POLICY "posts delete own or admin" ON public.group_posts FOR DELETE TO authenticated USING (user_id = auth.uid() OR public.is_group_admin(group_id, auth.uid()));

-- RIDE OFFERS
CREATE TABLE public.ride_offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  driver_id uuid NOT NULL,
  driver_name text NOT NULL DEFAULT 'Taxista',
  price_kz integer NOT NULL,
  phone text,
  message text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','rejected')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.ride_offers TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ride_offers TO authenticated;
GRANT ALL ON public.ride_offers TO service_role;
ALTER TABLE public.ride_offers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "offers readable" ON public.ride_offers FOR SELECT USING (true);
CREATE POLICY "offers insert own" ON public.ride_offers FOR INSERT TO authenticated WITH CHECK (driver_id = auth.uid());
CREATE POLICY "offers update admin" ON public.ride_offers FOR UPDATE TO authenticated USING (public.is_group_admin(group_id, auth.uid()));
CREATE POLICY "offers delete own" ON public.ride_offers FOR DELETE TO authenticated USING (driver_id = auth.uid());

-- ANNOUNCEMENTS (promoted to ads area)
CREATE TABLE public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid REFERENCES public.groups(id) ON DELETE CASCADE,
  created_by uuid NOT NULL,
  title text NOT NULL,
  body text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.announcements TO anon;
GRANT SELECT, INSERT, DELETE ON public.announcements TO authenticated;
GRANT ALL ON public.announcements TO service_role;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ann readable" ON public.announcements FOR SELECT USING (true);
CREATE POLICY "ann insert admin" ON public.announcements FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid() AND public.is_group_admin(group_id, auth.uid()));
CREATE POLICY "ann delete admin" ON public.announcements FOR DELETE TO authenticated USING (created_by = auth.uid() OR public.is_group_admin(group_id, auth.uid()));

ALTER PUBLICATION supabase_realtime ADD TABLE public.road_reports, public.report_votes, public.groups, public.group_members, public.group_posts, public.ride_offers, public.announcements;

-- STORAGE policies (bucket created separately)
CREATE POLICY "road photos upload own folder" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'road-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "road photos delete own" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'road-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
