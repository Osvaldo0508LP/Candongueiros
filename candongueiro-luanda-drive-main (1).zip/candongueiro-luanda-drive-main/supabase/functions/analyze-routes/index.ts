import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { createClient } from "npm:@supabase/supabase-js@2";

const ROUTES = [
  "Viana → Cidade Alta", "Cacuaco → Maianga", "Cazenga → Mutamba", "Kilamba → Largo 1º de Maio",
  "Benfica → São Paulo", "Rangel → Maculusso", "Zango → Mutamba", "Zango → Viana",
  "Aeroporto Novo (AIAAN) → Cidade Alta", "Viana → Aeroporto Novo (AIAAN)",
];

const schema = {
  type: "object",
  additionalProperties: false,
  required: ["summary", "routes", "work_now"],
  properties: {
    summary: { type: "string" },
    routes: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["route", "status", "reason", "alternative"],
        properties: {
          route: { type: "string" },
          status: { type: "string", enum: ["fluido", "lento", "evitar"] },
          reason: { type: "string" },
          alternative: { type: "string" },
        },
      },
    },
    work_now: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["zone", "reason"],
        properties: { zone: { type: "string" }, reason: { type: "string" } },
      },
    },
  },
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) return json({ error: "Configuração de IA em falta" }, 500);

    const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const since = new Date(Date.now() - 3 * 3600 * 1000).toISOString();
    const { data: reports } = await sb.from("road_reports").select("id,type,location,description,author_type,created_at").gte("created_at", since).order("created_at", { ascending: false }).limit(80);
    const ids = (reports ?? []).map((r) => r.id);
    const { data: votes } = ids.length ? await sb.from("report_votes").select("report_id,vote").in("report_id", ids) : { data: [] };

    const lines = (reports ?? []).map((r) => {
      const c = (votes ?? []).filter((v) => v.report_id === r.id && v.vote === "confirm").length;
      const d = (votes ?? []).filter((v) => v.report_id === r.id && v.vote === "dismiss").length;
      const mins = Math.round((Date.now() - new Date(r.created_at).getTime()) / 60000);
      return `- [${r.type}] ${r.location}: ${r.description ?? ""} (há ${mins} min, por ${r.author_type}, confirmações ${c}, "já não está" ${d})`;
    });

    const prompt = `És um assistente de trânsito para taxistas (candongueiros) em Luanda, Angola.
Rotas populares:
${ROUTES.join("\n")}

Reportes da comunidade nas últimas 3 horas:
${lines.length ? lines.join("\n") : "(sem reportes — usa conhecimento geral de Luanda e indica que a análise tem pouca informação)"}

Para cada rota popular, indica estado (fluido, lento ou evitar), motivo curto com base nos reportes e uma via alternativa real em Luanda.
Indica também 3 a 5 zonas onde os taxistas devem trabalhar agora (trânsito flui e há procura).
Dá mais peso a reportes recentes e confirmados; ignora os que têm mais "já não está" do que confirmações.
Responde em português de Angola, curto e prático.`;

    const resp = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "fetch" },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        input: prompt,
        reasoning: { effort: "low" },
        store: false,
        stream: true,
        text: { format: { type: "json_schema", name: "route_analysis", strict: true, schema } },
      }),
    });

    if (!resp.ok || !resp.body) {
      const t = await resp.text();
      let msg = "Falha na análise de IA";
      try { msg = JSON.parse(t)?.error?.message || JSON.parse(t)?.message || msg; } catch { /* ignore */ }
      if (resp.status === 429) msg = "Muitos pedidos. Tente novamente daqui a pouco.";
      if (resp.status === 402) msg = "Créditos de IA esgotados.";
      return json({ error: msg }, resp.status);
    }

    const reader = resp.body.getReader();
    const dec = new TextDecoder();
    let buf = "", text = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const parts = buf.split("\n");
      buf = parts.pop() ?? "";
      for (const line of parts) {
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (!data || data === "[DONE]") continue;
        try {
          const ev = JSON.parse(data);
          if (ev.type === "response.output_text.delta") text += ev.delta;
          if (ev.type === "error" || ev.type === "response.failed") return json({ error: "A IA não conseguiu responder" }, 502);
        } catch { /* ignore */ }
      }
    }
    if (!text) return json({ error: "A IA não devolveu resposta" }, 502);
    return json({ ...JSON.parse(text), reports_count: lines.length, generated_at: new Date().toISOString() });
  } catch (e) {
    return json({ error: (e as Error).message }, 500);
  }
});
