import { useState } from "react";
import { Sparkles, Loader2, ArrowRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

type Result = {
  summary: string;
  routes: { route: string; status: "fluido" | "lento" | "evitar"; reason: string; alternative: string }[];
  work_now: { zone: string; reason: string }[];
  reports_count: number;
};

const STATUS = {
  fluido: { label: "Fluido", cls: "bg-success text-primary-foreground" },
  lento: { label: "Lento", cls: "bg-warning text-foreground" },
  evitar: { label: "Evitar", cls: "bg-destructive text-destructive-foreground" },
};

const AiRoutes = () => {
  const [data, setData] = useState<Result | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    setLoading(true);
    setError(null);
    const { data: res, error: err } = await supabase.functions.invoke("analyze-routes", { body: {} });
    setLoading(false);
    if (err || res?.error) {
      let m = res?.error || "Não foi possível analisar agora.";
      try { const b = await (err as { context?: Response })?.context?.json(); if (b?.error) m = b.error; } catch { /* ignore */ }
      return setError(m);
    }
    setData(res as Result);
  };

  return (
    <div className="mb-6 p-4 rounded-xl bg-card border border-primary/30">
      <div className="flex items-center justify-between gap-2">
        <div>
          <p className="font-display font-semibold text-foreground flex items-center gap-2"><Sparkles className="h-4 w-4 text-primary" /> Rotas recomendadas por IA</p>
          <p className="text-xs text-muted-foreground">Analisa as fotos e alertas da comunidade das últimas 3 horas.</p>
        </div>
        <button onClick={run} disabled={loading} className="gradient-primary text-primary-foreground px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1 disabled:opacity-60 shrink-0">
          {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />} {loading ? "A analisar..." : "Analisar"}
        </button>
      </div>
      {error && <p className="text-xs text-destructive mt-3">{error}</p>}
      {data && (
        <div className="mt-4 space-y-4">
          <p className="text-sm text-foreground">{data.summary}</p>
          <p className="text-[10px] text-muted-foreground">Baseado em {data.reports_count} reportes recentes.</p>
          <div>
            <p className="text-xs font-semibold text-foreground mb-2">Onde trabalhar agora</p>
            <div className="flex flex-wrap gap-2">
              {data.work_now.map((w) => (
                <div key={w.zone} className="px-3 py-2 rounded-lg bg-accent text-accent-foreground text-xs"><b>{w.zone}</b> — {w.reason}</div>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            {data.routes.map((r) => (
              <div key={r.route} className="p-3 rounded-lg bg-muted">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-medium text-foreground">{r.route}</p>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${STATUS[r.status]?.cls}`}>{STATUS[r.status]?.label}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{r.reason}</p>
                {r.status !== "fluido" && <p className="text-xs text-primary mt-1 flex items-center gap-1"><ArrowRight className="h-3 w-3" /> {r.alternative}</p>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AiRoutes;
