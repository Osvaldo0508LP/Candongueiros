import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Megaphone } from "lucide-react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

type Ad = { id: string | number; company: string; title: string; desc: string; color: string };
const SAMPLE: Ad[] = [
  {
    id: 1,
    company: "MegaPlus Angola",
    title: "Internet Ilimitada 5G",
    desc: "Planos a partir de 2.500 Kz/mês. Cobertura total em Luanda!",
    color: "from-[hsl(215,80%,35%)] to-[hsl(215,70%,50%)]",
  },
  {
    id: 2,
    company: "Kero Supermercados",
    title: "Promoções da Semana",
    desc: "Até 30% de desconto em produtos seleccionados. Válido até domingo!",
    color: "from-[hsl(145,63%,42%)] to-[hsl(160,60%,40%)]",
  },
  {
    id: 3,
    company: "Xyami Delivery",
    title: "Comida ao Domicílio",
    desc: "Peça agora e receba em 30 minutos. Primeira encomenda grátis!",
    color: "from-[hsl(25,90%,50%)] to-[hsl(40,95%,55%)]",
  },
];

const AdBanner = () => {
  const [currentAd, setCurrentAd] = useState(0);
  const [dismissed, setDismissed] = useState(false);
  const [SAMPLE_ADS, setAds] = useState<Ad[]>(SAMPLE);

  useEffect(() => {
    supabase.from("announcements").select("id,title,body").order("created_at", { ascending: false }).limit(5)
      .then(({ data }) => {
        if (data?.length) setAds([...data.map((a) => ({ id: a.id, company: "Aviso da Comunidade", title: a.title, desc: a.body ?? "", color: "from-[hsl(0,70%,45%)] to-[hsl(25,85%,50%)]" })), ...SAMPLE]);
      });
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentAd((prev) => (prev + 1) % SAMPLE_ADS.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [SAMPLE_ADS.length]);

  if (dismissed) return null;

  const ad = SAMPLE_ADS[currentAd % SAMPLE_ADS.length];

  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        <motion.div
          key={ad.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className={`relative rounded-xl bg-gradient-to-r ${ad.color} p-4 text-primary-foreground overflow-hidden`}
        >
          <button
            onClick={() => setDismissed(true)}
            className="absolute top-2 right-2 p-1 rounded-full bg-primary-foreground/20 hover:bg-primary-foreground/30 transition-colors"
          >
            <X className="h-3 w-3" />
          </button>
          <div className="flex items-center gap-1 mb-1">
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-primary-foreground/20 font-medium">Patrocinado</span>
            <span className="text-[10px] opacity-80">{ad.company}</span>
          </div>
          <h3 className="font-display font-bold text-sm">{ad.title}</h3>
          <p className="text-xs opacity-90 mt-0.5">{ad.desc}</p>
        </motion.div>
      </AnimatePresence>

      {/* Dots */}
      <div className="flex justify-center gap-1.5 mt-2">
        {SAMPLE_ADS.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentAd(i)}
            className={`w-1.5 h-1.5 rounded-full transition-colors ${
              i === currentAd ? "bg-primary" : "bg-border"
            }`}
          />
        ))}
      </div>

      {/* CTA */}
      <Link
        to="/publicidade"
        className="mt-2 flex items-center justify-center gap-1 text-[10px] text-muted-foreground hover:text-primary transition-colors"
      >
        <Megaphone className="h-3 w-3" />
        Quer anunciar aqui? Saiba mais
      </Link>
    </div>
  );
};

export default AdBanner;
