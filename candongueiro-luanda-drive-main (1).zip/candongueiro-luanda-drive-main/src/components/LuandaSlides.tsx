import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

// Fotos públicas de Luanda (Wikimedia Commons, licenças livres)
const SLIDES = [
  { src: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Marginal_de_Luanda_HD_Dji_Mavic_3_Classic_-_By_D%C3%A9lcio_Geovany_Borges.jpg/1280px-Marginal_de_Luanda_HD_Dji_Mavic_3_Classic_-_By_D%C3%A9lcio_Geovany_Borges.jpg", caption: "Marginal de Luanda", credit: "Délcio Geovany Borges · CC BY 4.0" },
  { src: "https://thumb.wikimedia.org/wikipedia/commons/thumb/3/3b/Bay_of_Luanda.jpg/1280px-Bay_of_Luanda.jpg", caption: "Baía de Luanda", credit: "Paulo César Santos · CC0" },
  { src: "https://upload.wikimedia.org/wikipedia/commons/5/5c/Luanda_Skyline_-_Angola_2015.jpg", caption: "Skyline de Luanda", credit: "Flickr · CC BY 2.0" },
  { src: "https://upload.wikimedia.org/wikipedia/commons/9/97/Luanda_Marginal_at_night.jpg", caption: "Marginal à noite", credit: "Domínio público" },
  { src: "https://thumb.wikimedia.org/wikipedia/commons/thumb/a/ae/Marginal_Avenida_4_de_Fevreiro_Luanda_March_2013_%28cropped%29.JPG/1280px-Marginal_Avenida_4_de_Fevreiro_Luanda_March_2013_%28cropped%29.JPG", caption: "Avenida 4 de Fevereiro", credit: "CC BY-SA 3.0" },
  { src: "https://upload.wikimedia.org/wikipedia/commons/b/b3/Luanda_Bay_and_Ilha_de_Luanda.jpg", caption: "Baía e Ilha de Luanda", credit: "Domínio público" },
  { src: "https://upload.wikimedia.org/wikipedia/commons/0/0e/New_road_infrastructure_Luanda_Luanda_Bay_in_the_background.JPG", caption: "Novas estradas de Luanda", credit: "Rui Gabriel Correia · CC BY-SA 3.0" },
];

const LuandaSlides = () => {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((p) => (p + 1) % SLIDES.length), 5000);
    return () => clearInterval(t);
  }, []);
  const s = SLIDES[i];
  const go = (d: number) => setI((p) => (p + d + SLIDES.length) % SLIDES.length);

  return (
    <div className="relative rounded-2xl overflow-hidden aspect-[16/9] md:aspect-[21/8] bg-muted taxi-shadow">
      <AnimatePresence mode="wait">
        <motion.img
          key={s.src}
          src={s.src}
          alt={s.caption}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
          className="absolute inset-0 w-full h-full object-cover"
        />
      </AnimatePresence>
      <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-foreground/80 to-transparent">
        <p className="font-display font-bold text-primary-foreground">{s.caption}</p>
        <p className="text-[10px] text-primary-foreground/70">{s.credit}</p>
      </div>
      <button onClick={() => go(-1)} aria-label="Anterior" className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background/70 flex items-center justify-center">
        <ChevronLeft className="h-4 w-4 text-foreground" />
      </button>
      <button onClick={() => go(1)} aria-label="Seguinte" className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background/70 flex items-center justify-center">
        <ChevronRight className="h-4 w-4 text-foreground" />
      </button>
      <div className="absolute top-3 right-3 flex gap-1">
        {SLIDES.map((_, k) => (
          <span key={k} className={`h-1.5 rounded-full transition-all ${k === i ? "w-5 bg-primary-foreground" : "w-1.5 bg-primary-foreground/50"}`} />
        ))}
      </div>
    </div>
  );
};

export default LuandaSlides;
