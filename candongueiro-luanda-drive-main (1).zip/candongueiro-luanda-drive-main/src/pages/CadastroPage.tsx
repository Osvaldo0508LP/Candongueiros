import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  UserPlus, Car, User, Check, MapPin, Phone, Mail,
  CreditCard, FileText, Facebook, Chrome, ArrowRight,
  Shield, Star, Users, Sparkles
} from "lucide-react";
import taxiIcon from "@/assets/taxi-icon.png";
import hiaceImg from "@/assets/hiace-luanda.png";
import luandaStreet from "@/assets/luanda-street.jpg";

type UserType = "taxista" | "cliente";
type Step = "select" | "form" | "review" | "success";

const ZONES = [
  "Viana", "Cacuaco", "Cazenga", "Kilamba", "Benfica",
  "Rangel", "Maianga", "Mutamba", "São Paulo", "Maculusso", "Cidade Alta",
  "Zango", "Aeroporto Novo (AIAAN)"
];

const BENEFITS_TAXISTA = [
  { icon: Users, text: "Acesso à comunidade de taxistas" },
  { icon: MapPin, text: "Aparecer nas rotas populares" },
  { icon: Star, text: "Receber avaliações dos passageiros" },
];

const BENEFITS_CLIENTE = [
  { icon: Car, text: "Encontrar táxis rapidamente" },
  { icon: Shield, text: "Taxistas verificados" },
  { icon: Users, text: "Comunidade de passageiros" },
];

const CadastroPage = () => {
  const [userType, setUserType] = useState<UserType | null>(null);
  const [step, setStep] = useState<Step>("select");

  const [driverForm, setDriverForm] = useState({
    name: "", phone: "", email: "", bi: "",
    carBrand: "", carModel: "", carYear: "", carPlate: "", carColor: "Azul e Branco",
    zones: [] as string[],
  });

  const [clientForm, setClientForm] = useState({
    name: "", phone: "", email: "", zone: "",
  });

  const toggleZone = (zone: string) => {
    setDriverForm((prev) => ({
      ...prev,
      zones: prev.zones.includes(zone)
        ? prev.zones.filter((z) => z !== zone)
        : [...prev.zones, zone],
    }));
  };

  const handleSocialLogin = (provider: string) => {
    // Simulação — numa app real usaria OAuth
    alert(`Login com ${provider} — em breve disponível! Por agora, preencha o formulário.`);
  };

  const handleSelectType = (type: UserType) => {
    setUserType(type);
    setStep("form");
  };

  const handleGoToReview = () => setStep("review");
  const handleSubmit = () => setStep("success");

  const handleReset = () => {
    setStep("select");
    setUserType(null);
    setDriverForm({ name: "", phone: "", email: "", bi: "", carBrand: "", carModel: "", carYear: "", carPlate: "", carColor: "Azul e Branco", zones: [] });
    setClientForm({ name: "", phone: "", email: "", zone: "" });
  };

  const progress = step === "select" ? 0 : step === "form" ? 33 : step === "review" ? 66 : 100;

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Street background with HiAce */}
      <div className="fixed inset-0 -z-10">
        <img src={luandaStreet} alt="Ruas de Luanda" className="w-full h-full object-cover" />
        {/* HiAce circulando no fundo */}
        <motion.div
          initial={{ x: "-20%" }}
          animate={{ x: "120%" }}
          transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-[15%] w-[18%] min-w-[140px] max-w-[260px]"
        >
          <img src={hiaceImg} alt="HiAce a circular em Luanda" className="w-full h-auto drop-shadow-2xl" style={{ transform: "scaleX(-1)" }} />
        </motion.div>
        <div className="absolute inset-0" style={{ background: "hsla(215, 80%, 35%, 0.6)" }} />
      </div>

      <div className="container py-6 max-w-lg mx-auto relative z-20">
      {step !== "select" && step !== "success" && (
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
            <span>Tipo</span>
            <span>Dados</span>
            <span>Revisão</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <motion.div
              className="h-full gradient-primary rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.4 }}
            />
          </div>
        </div>
      )}

      <AnimatePresence mode="wait">
        {/* STEP: SELECT TYPE */}
        {step === "select" && (
          <motion.div key="select" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
            <div className="text-center mb-8">
              <div className="w-14 h-14 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-3">
                <UserPlus className="h-7 w-7 text-primary-foreground" />
              </div>
              <h1 className="font-display font-bold text-2xl text-foreground mb-1">Junte-se ao CANDONGUEIRO</h1>
              <p className="text-muted-foreground text-sm">Crie a sua conta e comece a usar</p>
            </div>

            {/* Social Login */}
            <div className="space-y-3 mb-6">
              <button
                onClick={() => handleSocialLogin("Google")}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-card border border-border hover:border-primary/30 hover:taxi-shadow transition-all text-sm font-medium text-foreground"
              >
                <Chrome className="h-5 w-5 text-primary" />
                Continuar com Google
              </button>
              <button
                onClick={() => handleSocialLogin("Facebook")}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-card border border-border hover:border-primary/30 hover:taxi-shadow transition-all text-sm font-medium text-foreground"
              >
                <Facebook className="h-5 w-5 text-[hsl(220,80%,50%)]" />
                Continuar com Facebook
              </button>
            </div>

            <div className="flex items-center gap-3 mb-6">
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs text-muted-foreground">ou registe-se manualmente</span>
              <div className="flex-1 h-px bg-border" />
            </div>

            {/* Type Selection */}
            <div className="grid grid-cols-2 gap-4">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleSelectType("taxista")}
                className="p-5 rounded-xl bg-card border border-border hover:border-primary/30 hover:taxi-shadow transition-all text-center group"
              >
                <img src={taxiIcon} alt="Táxi" className="w-14 h-14 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <h3 className="font-display font-bold text-foreground text-sm mb-1">Sou Taxista</h3>
                <p className="text-[10px] text-muted-foreground">Registar-me e o meu carro</p>
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleSelectType("cliente")}
                className="p-5 rounded-xl bg-card border border-border hover:border-primary/30 hover:taxi-shadow transition-all text-center group"
              >
                <div className="w-14 h-14 rounded-full bg-accent flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                  <User className="h-7 w-7 text-accent-foreground" />
                </div>
                <h3 className="font-display font-bold text-foreground text-sm mb-1">Sou Passageiro</h3>
                <p className="text-[10px] text-muted-foreground">Encontrar táxis facilmente</p>
              </motion.button>
            </div>

            {/* Benefits */}
            <div className="mt-8 p-4 rounded-xl bg-accent/30 border border-accent">
              <p className="text-xs font-semibold text-accent-foreground mb-3 flex items-center gap-1">
                <Sparkles className="h-3.5 w-3.5" /> Vantagens de se registar
              </p>
              <div className="grid grid-cols-2 gap-2">
                {[...BENEFITS_TAXISTA.slice(0, 2), ...BENEFITS_CLIENTE.slice(0, 2)].map((b, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-foreground">
                    <b.icon className="h-3.5 w-3.5 text-primary shrink-0" />
                    {b.text}
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* STEP: FORM */}
        {step === "form" && userType === "taxista" && (
          <motion.div key="form-taxista" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <button onClick={() => setStep("select")} className="text-sm text-primary mb-4 hover:underline">← Voltar</button>
            <div className="p-5 rounded-xl bg-card border border-border space-y-4">
              <h2 className="font-display font-semibold text-foreground flex items-center gap-2">
                <Car className="h-5 w-5 text-primary" />
                Registo de Taxista
              </h2>

              <div className="space-y-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Dados Pessoais</p>
                <InputField icon={User} placeholder="Nome completo" value={driverForm.name} onChange={(v) => setDriverForm({ ...driverForm, name: v })} />
                <InputField icon={Phone} placeholder="Telefone (ex: 923 456 789)" type="tel" value={driverForm.phone} onChange={(v) => setDriverForm({ ...driverForm, phone: v })} />
                <InputField icon={Mail} placeholder="Email (opcional)" type="email" value={driverForm.email} onChange={(v) => setDriverForm({ ...driverForm, email: v })} />
                <InputField icon={CreditCard} placeholder="Nº do BI" value={driverForm.bi} onChange={(v) => setDriverForm({ ...driverForm, bi: v })} />
              </div>

              <div className="space-y-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Dados do Veículo</p>
                <div className="grid grid-cols-2 gap-3">
                  <input type="text" placeholder="Marca" value={driverForm.carBrand} onChange={(e) => setDriverForm({ ...driverForm, carBrand: e.target.value })} className="px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none" />
                  <input type="text" placeholder="Modelo" value={driverForm.carModel} onChange={(e) => setDriverForm({ ...driverForm, carModel: e.target.value })} className="px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <input type="text" placeholder="Ano" value={driverForm.carYear} onChange={(e) => setDriverForm({ ...driverForm, carYear: e.target.value })} className="px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none" />
                  <input type="text" placeholder="Matrícula" value={driverForm.carPlate} onChange={(e) => setDriverForm({ ...driverForm, carPlate: e.target.value })} className="px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none" />
                </div>
                <input type="text" placeholder="Cor do veículo" value={driverForm.carColor} onChange={(e) => setDriverForm({ ...driverForm, carColor: e.target.value })} className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none" />
              </div>

              <div className="space-y-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Zonas de Trabalho</p>
                <div className="flex flex-wrap gap-2">
                  {ZONES.map((zone) => (
                    <motion.button
                      key={zone}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => toggleZone(zone)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                        driverForm.zones.includes(zone)
                          ? "gradient-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground border border-border hover:border-primary/30"
                      }`}
                    >
                      {zone}
                    </motion.button>
                  ))}
                </div>
              </div>

              <button onClick={handleGoToReview} className="w-full gradient-primary text-primary-foreground py-3 rounded-lg font-semibold text-sm flex items-center justify-center gap-2">
                Continuar <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </motion.div>
        )}

        {step === "form" && userType === "cliente" && (
          <motion.div key="form-cliente" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <button onClick={() => setStep("select")} className="text-sm text-primary mb-4 hover:underline">← Voltar</button>
            <div className="p-5 rounded-xl bg-card border border-border space-y-4">
              <h2 className="font-display font-semibold text-foreground flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                Registo de Passageiro
              </h2>

              <div className="space-y-3">
                <InputField icon={User} placeholder="Nome completo" value={clientForm.name} onChange={(v) => setClientForm({ ...clientForm, name: v })} />
                <InputField icon={Phone} placeholder="Telefone (ex: 923 456 789)" type="tel" value={clientForm.phone} onChange={(v) => setClientForm({ ...clientForm, phone: v })} />
                <InputField icon={Mail} placeholder="Email (opcional)" type="email" value={clientForm.email} onChange={(v) => setClientForm({ ...clientForm, email: v })} />
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <select
                    value={clientForm.zone}
                    onChange={(e) => setClientForm({ ...clientForm, zone: e.target.value })}
                    className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-muted text-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none"
                  >
                    <option value="">Zona onde vive</option>
                    {ZONES.map((z) => <option key={z} value={z}>{z}</option>)}
                  </select>
                </div>
              </div>

              {/* Benefits */}
              <div className="p-3 rounded-lg bg-accent/30 border border-accent space-y-2">
                {BENEFITS_CLIENTE.map((b, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-foreground">
                    <b.icon className="h-3.5 w-3.5 text-primary shrink-0" />
                    {b.text}
                  </div>
                ))}
              </div>

              <button onClick={handleGoToReview} className="w-full gradient-primary text-primary-foreground py-3 rounded-lg font-semibold text-sm flex items-center justify-center gap-2">
                Continuar <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </motion.div>
        )}

        {/* STEP: REVIEW */}
        {step === "review" && (
          <motion.div key="review" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <button onClick={() => setStep("form")} className="text-sm text-primary mb-4 hover:underline">← Voltar</button>
            <div className="p-5 rounded-xl bg-card border border-border space-y-4">
              <h2 className="font-display font-semibold text-foreground flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Revisão dos Dados
              </h2>
              <p className="text-xs text-muted-foreground">Confirme se os dados estão correctos antes de submeter.</p>

              {userType === "taxista" ? (
                <div className="space-y-3">
                  <ReviewRow label="Nome" value={driverForm.name} />
                  <ReviewRow label="Telefone" value={driverForm.phone} />
                  <ReviewRow label="Email" value={driverForm.email || "Não informado"} />
                  <ReviewRow label="BI" value={driverForm.bi} />
                  <div className="h-px bg-border" />
                  <ReviewRow label="Veículo" value={`${driverForm.carBrand} ${driverForm.carModel} ${driverForm.carYear}`} />
                  <ReviewRow label="Matrícula" value={driverForm.carPlate} />
                  <ReviewRow label="Cor" value={driverForm.carColor} />
                  <ReviewRow label="Zonas" value={driverForm.zones.join(", ") || "Nenhuma"} />
                </div>
              ) : (
                <div className="space-y-3">
                  <ReviewRow label="Nome" value={clientForm.name} />
                  <ReviewRow label="Telefone" value={clientForm.phone} />
                  <ReviewRow label="Email" value={clientForm.email || "Não informado"} />
                  <ReviewRow label="Zona" value={clientForm.zone || "Não informada"} />
                </div>
              )}

              <div className="flex items-center gap-2 p-3 rounded-lg bg-accent/30 border border-accent">
                <Shield className="h-4 w-4 text-primary shrink-0" />
                <p className="text-xs text-foreground">Os seus dados são protegidos e nunca serão partilhados sem a sua autorização.</p>
              </div>

              <button onClick={handleSubmit} className="w-full gradient-primary text-primary-foreground py-3 rounded-lg font-semibold text-sm">
                Confirmar Cadastro
              </button>
            </div>
          </motion.div>
        )}

        {/* STEP: SUCCESS */}
        {step === "success" && (
          <motion.div key="success" initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center py-12">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
              className="w-20 h-20 rounded-full bg-[hsl(var(--success))]/10 flex items-center justify-center mx-auto mb-4"
            >
              <Check className="h-10 w-10 text-[hsl(var(--success))]" />
            </motion.div>
            <h2 className="font-display font-bold text-2xl text-foreground mb-2">Cadastro Enviado! 🎉</h2>
            <p className="text-muted-foreground text-sm mb-2 max-w-sm mx-auto">
              {userType === "taxista"
                ? "O seu registo como taxista foi recebido. Em breve poderá começar a usar o CANDONGUEIRO."
                : "O seu registo como passageiro foi recebido. Agora pode encontrar táxis facilmente!"}
            </p>
            <p className="text-xs text-muted-foreground mb-6">Receberá uma confirmação no seu telefone.</p>

            <div className="flex gap-3 justify-center">
              <button onClick={handleReset} className="gradient-primary text-primary-foreground px-6 py-2.5 rounded-lg text-sm font-semibold">
                Novo Cadastro
              </button>
              <a href="/" className="px-6 py-2.5 rounded-lg text-sm font-semibold border border-border text-foreground hover:bg-muted transition-colors">
                Ir para Início
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      </div>
    </div>
  );
};

/* Reusable input with icon */
const InputField = ({ icon: Icon, placeholder, value, onChange, type = "text" }: {
  icon: React.ElementType; placeholder: string; value: string;
  onChange: (v: string) => void; type?: string;
}) => (
  <div className="relative">
    <Icon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
    <input
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none transition-all"
    />
  </div>
);

/* Review row */
const ReviewRow = ({ label, value }: { label: string; value: string }) => (
  <div className="flex justify-between items-start">
    <span className="text-xs text-muted-foreground">{label}</span>
    <span className="text-sm font-medium text-foreground text-right max-w-[60%]">{value}</span>
  </div>
);

export default CadastroPage;
