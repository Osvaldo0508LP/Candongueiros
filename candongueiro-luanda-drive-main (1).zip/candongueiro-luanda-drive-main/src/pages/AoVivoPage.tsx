import { useEffect, useRef, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, Radio, MapPin, ThumbsUp, ThumbsDown, Trash2, X, Send } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, displayName, timeAgo } from "@/hooks/useAuth";

const TYPES: Record<string, { label: string; cls: string }> = {
  transito: { label: "Trânsito", cls: "bg-warning text-foreground" },
  operacao: { label: "Operação", cls: "bg-destructive text-destructive-foreground" },
  obstrucao: { label: "Obstrução", cls: "bg-warning text-foreground" },
  acidente: { label: "Acidente", cls: "bg-destructive text-destructive-foreground" },
  livre: { label: "Via livre", cls: "bg-success text-primary-foreground" },
};

interface Report {
  id: string;
  user_id: string;
  author_name: string;
  author_type: string;
  type: string;
  location: string;
  description: string | null;
  photo_url: string | null;
  created_at: string;
}
interface Vote { report_id: string; user_id: string; vote: string }

const AoVivoPage = () => {
  const { user, profile } = useAuth();
  const [reports, setReports] = useState<Report[]>([]);
  const [votes, setVotes] = useState<Vote[]>([]);
  const [urls, setUrls] = useState<Record<string, string>>({});
  const [filter, setFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ type: "transito", location: "", description: "" });
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    const since = new Date(Date.now() - 3 * 3600 * 1000).toISOString();
    const { data } = await supabase.from("road_reports").select("*").gte("created_at", since).order("created_at", { ascending: false }).limit(100);
    const list = (data as Report[]) || [];
    setReports(list);
    if (list.length) {
      const { data: v } = await supabase.from("report_votes").select("report_id,user_id,vote").in("report_id", list.map((r) => r.id));
      setVotes((v as Vote[]) || []);
      const paths = list.map((r) => r.photo_url).filter(Boolean) as string[];
      if (paths.length) {
        const { data: signed } = await supabase.storage.from("road-photos").createSignedUrls(paths, 3600);
        const map: Record<string, string> = {};
        signed?.forEach((s) => s.path && s.signedUrl && (map[s.path] = s.signedUrl));
        setUrls(map);
      }
    }
  }, []);

  useEffect(() => {
    load();
    const ch = supabase
      .channel("ao-vivo")
      .on("postgres_changes", { event: "*", schema: "public", table: "road_reports" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "report_votes" }, () => load())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [load]);

  const pickFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };

  const submit = async () => {
    if (!user) return;
    if (!form.location.trim()) return toast.error("Indique a localização");
    setBusy(true);
    try {
      let photo_url: string | null = null;
      if (file) {
        const ext = file.name.split(".").pop() || "jpg";
        const path = `${user.id}/${Date.now()}.${ext}`;
        const { error } = await supabase.storage.from("road-photos").upload(path, file, { contentType: file.type });
        if (error) throw error;
        photo_url = path;
      }
      const { error } = await supabase.from("road_reports").insert({
        user_id: user.id,
        author_name: displayName(profile, user),
        author_type: profile?.user_type || "passageiro",
        type: form.type,
        location: form.location.trim(),
        description: form.description.trim() || null,
        photo_url,
      });
      if (error) throw error;
      toast.success("Publicado! Todos já podem ver.");
      setForm({ type: "transito", location: "", description: "" });
      setFile(null);
      setPreview(null);
      setShowForm(false);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const vote = async (id: string, v: "confirm" | "dismiss") => {
    if (!user) return toast.error("Entre na sua conta para votar");
    const mine = votes.find((x) => x.report_id === id && x.user_id === user.id);
    if (mine?.vote === v) await supabase.from("report_votes").delete().eq("report_id", id).eq("user_id", user.id);
    else await supabase.from("report_votes").upsert({ report_id: id, user_id: user.id, vote: v });
  };

  const remove = async (id: string) => {
    await supabase.from("road_reports").delete().eq("id", id);
  };

  const shown = filter === "all" ? reports : reports.filter((r) => r.type === filter);

  return (
    <div className="container py-6 max-w-2xl">
      <div className="flex items-center justify-between mb-1">
        <h1 className="font-display font-bold text-2xl text-foreground flex items-center gap-2">
          <Radio className="h-6 w-6 text-destructive animate-pulse" />
          Via Ao Vivo
        </h1>
        {user ? (
          <button onClick={() => setShowForm(!showForm)} className="gradient-primary text-primary-foreground px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1">
            <Camera className="h-3.5 w-3.5" /> Publicar
          </button>
        ) : (
          <Link to="/entrar" className="gradient-primary text-primary-foreground px-3 py-2 rounded-lg text-xs font-semibold">Entrar para publicar</Link>
        )}
      </div>
      <p className="text-muted-foreground text-sm mb-5">Fotos das vias publicadas por taxistas e passageiros — actualiza sozinho.</p>

      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="mb-5 p-4 rounded-xl bg-card border border-border space-y-3 overflow-hidden">
            <div className="flex gap-2 flex-wrap">
              {Object.entries(TYPES).map(([k, v]) => (
                <button key={k} onClick={() => setForm({ ...form, type: k })} className={`px-3 py-1.5 rounded-full text-xs font-medium ${form.type === k ? v.cls : "bg-muted text-muted-foreground"}`}>
                  {v.label}
                </button>
              ))}
            </div>
            <input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Onde? (ex: Ponte do Zango)" className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground text-sm border border-border" />
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="O que está a acontecer?" rows={2} className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground text-sm border border-border resize-none" />
            <input ref={fileRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={pickFile} />
            {preview ? (
              <div className="relative">
                <img src={preview} alt="Pré-visualização" className="w-full max-h-64 object-cover rounded-lg" />
                <button onClick={() => { setFile(null); setPreview(null); }} className="absolute top-2 right-2 w-7 h-7 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center">
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button onClick={() => fileRef.current?.click()} className="w-full py-6 rounded-lg border-2 border-dashed border-border text-sm text-muted-foreground flex flex-col items-center gap-1 hover:border-primary/50">
                <Camera className="h-6 w-6" /> Tirar ou escolher foto
              </button>
            )}
            <button disabled={busy} onClick={submit} className="w-full gradient-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-60">
              <Send className="h-4 w-4" /> {busy ? "A publicar..." : "Publicar agora"}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex gap-2 overflow-x-auto pb-3 mb-3">
        {[["all", "Todos"], ...Object.entries(TYPES).map(([k, v]) => [k, v.label])].map(([k, l]) => (
          <button key={k} onClick={() => setFilter(k)} className={`whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-medium ${filter === k ? "gradient-primary text-primary-foreground" : "bg-card text-muted-foreground border border-border"}`}>
            {l}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {shown.length === 0 && (
          <div className="text-center py-12 text-muted-foreground text-sm">
            <Camera className="h-10 w-10 mx-auto mb-2 opacity-40" />
            Nenhuma publicação nas últimas 3 horas. Seja o primeiro!
          </div>
        )}
        {shown.map((r) => {
          const t = TYPES[r.type] || TYPES.transito;
          const c = votes.filter((v) => v.report_id === r.id && v.vote === "confirm").length;
          const d = votes.filter((v) => v.report_id === r.id && v.vote === "dismiss").length;
          const mine = votes.find((v) => v.report_id === r.id && v.user_id === user?.id)?.vote;
          return (
            <motion.div key={r.id} layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-xl bg-card border border-border overflow-hidden">
              <div className="p-3 flex items-center gap-2">
                <div className="w-8 h-8 rounded-full gradient-primary flex items-center justify-center text-xs font-bold text-primary-foreground">
                  {r.author_name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">{r.author_name} <span className="text-[10px] font-normal text-muted-foreground capitalize">· {r.author_type}</span></p>
                  <p className="text-[10px] text-muted-foreground">{timeAgo(r.created_at)}</p>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${t.cls}`}>{t.label}</span>
                {user?.id === r.user_id && (
                  <button onClick={() => remove(r.id)} className="p-1 text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
                )}
              </div>
              {r.photo_url && urls[r.photo_url] && <img src={urls[r.photo_url]} alt={r.location} className="w-full max-h-96 object-cover" loading="lazy" />}
              <div className="p-3">
                <p className="text-sm font-medium text-foreground flex items-center gap-1"><MapPin className="h-3.5 w-3.5 text-primary" />{r.location}</p>
                {r.description && <p className="text-sm text-muted-foreground mt-1">{r.description}</p>}
                <div className="flex gap-2 mt-3">
                  <button onClick={() => vote(r.id, "confirm")} className={`flex-1 py-2 rounded-lg text-xs font-medium flex items-center justify-center gap-1 ${mine === "confirm" ? "bg-success text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                    <ThumbsUp className="h-3.5 w-3.5" /> Confirmo ({c})
                  </button>
                  <button onClick={() => vote(r.id, "dismiss")} className={`flex-1 py-2 rounded-lg text-xs font-medium flex items-center justify-center gap-1 ${mine === "dismiss" ? "bg-destructive text-destructive-foreground" : "bg-muted text-muted-foreground"}`}>
                    <ThumbsDown className="h-3.5 w-3.5" /> Já não está ({d})
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default AoVivoPage;
