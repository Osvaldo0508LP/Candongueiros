import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Car, User as UserIcon, LogIn } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/hooks/useAuth";

const AuthPage = () => {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [userType, setUserType] = useState<"taxista" | "passageiro">("passageiro");
  const [busy, setBusy] = useState(false);
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin, data: { display_name: name, user_type: userType } },
        });
        if (error) throw error;
        toast.success("Conta criada! Verifique o seu email para confirmar.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Bem-vindo de volta!");
        navigate("/ao-vivo");
      }
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (result.error) toast.error("Não foi possível entrar com Google");
  };

  const updateType = async (t: string) => {
    if (!user) return;
    await supabase.from("profiles").update({ user_type: t }).eq("id", user.id);
    toast.success("Perfil actualizado");
    window.location.reload();
  };

  if (user) {
    return (
      <div className="container py-10 max-w-md">
        <div className="p-6 rounded-xl bg-card border border-border text-center space-y-4">
          <div className="w-14 h-14 mx-auto rounded-full gradient-primary flex items-center justify-center">
            <UserIcon className="h-7 w-7 text-primary-foreground" />
          </div>
          <div>
            <p className="font-display font-bold text-lg text-foreground">{profile?.display_name}</p>
            <p className="text-sm text-muted-foreground">{user.email}</p>
          </div>
          <div className="flex gap-2 justify-center">
            {(["passageiro", "taxista"] as const).map((t) => (
              <button
                key={t}
                onClick={() => updateType(t)}
                className={`px-4 py-2 rounded-lg text-sm font-medium capitalize ${
                  profile?.user_type === t ? "gradient-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
          <button onClick={signOut} className="w-full py-2.5 rounded-lg border border-border text-sm text-foreground hover:bg-muted">
            Terminar sessão
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-10 max-w-md">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="p-6 rounded-xl bg-card border border-border">
        <div className="flex items-center gap-2 mb-1">
          <LogIn className="h-5 w-5 text-primary" />
          <h1 className="font-display font-bold text-xl text-foreground">{mode === "login" ? "Entrar" : "Criar conta"}</h1>
        </div>
        <p className="text-sm text-muted-foreground mb-5">Necessário para publicar fotos, criar grupos e fazer propostas.</p>

        <button onClick={google} className="w-full py-2.5 rounded-lg border border-border bg-background text-sm font-medium text-foreground hover:bg-muted mb-4">
          Continuar com Google
        </button>
        <div className="text-center text-xs text-muted-foreground mb-4">ou com email</div>

        <form onSubmit={submit} className="space-y-3">
          {mode === "signup" && (
            <>
              <input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome" className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground text-sm border border-border" />
              <div className="grid grid-cols-2 gap-2">
                {(["passageiro", "taxista"] as const).map((t) => (
                  <button
                    type="button"
                    key={t}
                    onClick={() => setUserType(t)}
                    className={`py-3 rounded-lg text-sm font-medium flex flex-col items-center gap-1 capitalize ${
                      userType === t ? "gradient-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {t === "taxista" ? <Car className="h-4 w-4" /> : <UserIcon className="h-4 w-4" />}
                    {t}
                  </button>
                ))}
              </div>
            </>
          )}
          <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground text-sm border border-border" />
          <input required type="password" minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Palavra-passe" className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground text-sm border border-border" />
          <button disabled={busy} className="w-full gradient-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold disabled:opacity-60">
            {busy ? "Aguarde..." : mode === "login" ? "Entrar" : "Criar conta"}
          </button>
        </form>
        <button onClick={() => setMode(mode === "login" ? "signup" : "login")} className="w-full mt-4 text-xs text-primary">
          {mode === "login" ? "Não tem conta? Criar conta" : "Já tem conta? Entrar"}
        </button>
      </motion.div>
    </div>
  );
};

export default AuthPage;
