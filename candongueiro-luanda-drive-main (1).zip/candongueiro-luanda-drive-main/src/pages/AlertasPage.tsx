import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { AlertTriangle, MapPin, Clock, Plus, Shield, Construction, CarFront, MessageCircle, Camera, X, Image as ImageIcon } from "lucide-react";

type AlertType = "operacao" | "obstrucao" | "transito" | "acidente";

interface Alert {
  id: number;
  type: AlertType;
  title: string;
  location: string;
  description: string;
  time: string;
  reports: number;
  photos?: string[];
}

const ALERT_CONFIG: Record<AlertType, { label: string; icon: typeof AlertTriangle; colorClass: string }> = {
  operacao: { label: "Operação Policial", icon: Shield, colorClass: "bg-destructive text-destructive-foreground" },
  obstrucao: { label: "Obstrução na Via", icon: Construction, colorClass: "bg-warning text-foreground" },
  transito: { label: "Trânsito Intenso", icon: CarFront, colorClass: "gradient-primary text-primary-foreground" },
  acidente: { label: "Acidente", icon: AlertTriangle, colorClass: "bg-destructive text-destructive-foreground" },
};

const INITIAL_ALERTS: Alert[] = [
  { id: 1, type: "operacao", title: "Operação Stop na Via Expresso", location: "Via Expresso, perto do Lar do Patriota", description: "Polícia de trânsito a parar viaturas. Evitar esta via.", time: "Há 15 min", reports: 23 },
  { id: 2, type: "obstrucao", title: "Estrada cortada por obras", location: "Av. Hoji Ya Henda, Cazenga", description: "Obras de repavimentação, via cortada nos dois sentidos.", time: "Há 1 hora", reports: 45 },
  { id: 3, type: "transito", title: "Trânsito parado no Largo", location: "Largo 1º de Maio", description: "Engarrafamento intenso em todas as direcções.", time: "Há 30 min", reports: 67 },
  { id: 4, type: "acidente", title: "Acidente na estrada de Catete", location: "Estrada de Catete, km 12", description: "Colisão entre duas viaturas. Trânsito lento.", time: "Há 45 min", reports: 34 },
  { id: 5, type: "operacao", title: "Fiscalização na Maianga", location: "Rua Comandante Gika, Maianga", description: "Fiscalização de documentos e licenças.", time: "Há 2 horas", reports: 12 },
];

const AlertasPage = () => {
  const [alerts, setAlerts] = useState<Alert[]>(INITIAL_ALERTS);
  const [filter, setFilter] = useState<AlertType | "all">("all");
  const [showForm, setShowForm] = useState(false);
  const [newAlert, setNewAlert] = useState({ type: "obstrucao" as AlertType, title: "", location: "", description: "" });
  const [selectedPhotos, setSelectedPhotos] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filtered = filter === "all" ? alerts : alerts.filter((a) => a.type === filter);

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newPhotos: string[] = [];
    Array.from(files).slice(0, 4 - selectedPhotos.length).forEach((file) => {
      const url = URL.createObjectURL(file);
      newPhotos.push(url);
    });
    setSelectedPhotos((prev) => [...prev, ...newPhotos].slice(0, 4));
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removePhoto = (index: number) => {
    setSelectedPhotos((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    if (!newAlert.title || !newAlert.location) return;
    setAlerts([
      { ...newAlert, id: Date.now(), time: "Agora", reports: 1, photos: selectedPhotos.length > 0 ? selectedPhotos : undefined },
      ...alerts,
    ]);
    setNewAlert({ type: "obstrucao", title: "", location: "", description: "" });
    setSelectedPhotos([]);
    setShowForm(false);
  };

  return (
    <div className="container py-6">
      <Link to="/ao-vivo" className="mb-4 flex items-center justify-between gap-3 p-4 rounded-xl gradient-primary text-primary-foreground">
        <span className="text-sm font-semibold">📸 Publique alertas com fotos em tempo real — ficam gravados para todos</span>
        <span className="text-xs underline whitespace-nowrap">Via Ao Vivo →</span>
      </Link>
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center justify-between mb-1">
          <h1 className="font-display font-bold text-2xl text-foreground flex items-center gap-2">
            <AlertTriangle className="h-6 w-6 text-warning" />
            Alertas de Via
          </h1>
          <button
            onClick={() => setShowForm(!showForm)}
            className="gradient-primary text-primary-foreground px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1"
          >
            <Plus className="h-3 w-3" />
            Reportar
          </button>
        </div>
        <p className="text-muted-foreground text-sm mb-6">
          Informações da comunidade sobre operações, obstruções e trânsito
        </p>
      </motion.div>

      {/* New alert form */}
      {showForm && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="mb-6 p-4 rounded-xl bg-card border border-border"
        >
          <p className="font-display font-semibold text-foreground mb-3">Reportar Alerta</p>
          <div className="space-y-3">
            <select
              value={newAlert.type}
              onChange={(e) => setNewAlert({ ...newAlert, type: e.target.value as AlertType })}
              className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground text-sm border border-border"
            >
              <option value="operacao">Operação Policial</option>
              <option value="obstrucao">Obstrução na Via</option>
              <option value="transito">Trânsito Intenso</option>
              <option value="acidente">Acidente</option>
            </select>
            <input
              type="text"
              placeholder="Título do alerta"
              value={newAlert.title}
              onChange={(e) => setNewAlert({ ...newAlert, title: e.target.value })}
              className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border"
            />
            <input
              type="text"
              placeholder="Localização (ex: Via Expresso)"
              value={newAlert.location}
              onChange={(e) => setNewAlert({ ...newAlert, location: e.target.value })}
              className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border"
            />
            <textarea
              placeholder="Descrição..."
              value={newAlert.description}
              onChange={(e) => setNewAlert({ ...newAlert, description: e.target.value })}
              className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border resize-none"
              rows={2}
            />

            {/* Photo upload */}
            <div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handlePhotoSelect}
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={selectedPhotos.length >= 4}
                className="flex items-center gap-2 px-3 py-2.5 rounded-lg border border-dashed border-border text-sm text-muted-foreground hover:border-primary/50 hover:text-foreground transition-colors w-full justify-center disabled:opacity-50"
              >
                <Camera className="h-4 w-4" />
                {selectedPhotos.length === 0 ? "Adicionar fotos (máx. 4)" : `${selectedPhotos.length}/4 fotos`}
              </button>
              {selectedPhotos.length > 0 && (
                <div className="flex gap-2 mt-2 flex-wrap">
                  {selectedPhotos.map((photo, idx) => (
                    <div key={idx} className="relative w-16 h-16 rounded-lg overflow-hidden border border-border">
                      <img src={photo} alt={`Foto ${idx + 1}`} className="w-full h-full object-cover" />
                      <button
                        onClick={() => removePhoto(idx)}
                        className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center"
                      >
                        <X className="h-2.5 w-2.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={handleSubmit}
              className="w-full gradient-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold"
            >
              Enviar Alerta
            </button>
          </div>
        </motion.div>
      )}

      {/* Filters */}
      <div className="flex gap-2 overflow-x-auto pb-3 mb-4">
        {[{ key: "all", label: "Todos" }, ...Object.entries(ALERT_CONFIG).map(([key, val]) => ({ key, label: val.label }))].map(
          (f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key as AlertType | "all")}
              className={`whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                filter === f.key
                  ? "gradient-primary text-primary-foreground"
                  : "bg-card text-muted-foreground border border-border hover:border-primary/30"
              }`}
            >
              {f.label}
            </button>
          )
        )}
      </div>

      {/* Alert list */}
      <div className="space-y-3">
        {filtered.map((alert, i) => {
          const config = ALERT_CONFIG[alert.type];
          const Icon = config.icon;
          return (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.05 * i }}
              className="p-4 rounded-xl bg-card border border-border"
            >
              <div className="flex items-start gap-3">
                <div className={`w-9 h-9 rounded-lg ${config.colorClass} flex items-center justify-center shrink-0`}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${config.colorClass}`}>
                      {config.label}
                    </span>
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                      <Clock className="h-2.5 w-2.5" />
                      {alert.time}
                    </span>
                  </div>
                  <h3 className="text-sm font-semibold text-foreground">{alert.title}</h3>
                  <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                    <MapPin className="h-3 w-3" />
                    {alert.location}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">{alert.description}</p>
                  {alert.photos && alert.photos.length > 0 && (
                    <div className="flex gap-2 mt-2 flex-wrap">
                      {alert.photos.map((photo, idx) => (
                        <img
                          key={idx}
                          src={photo}
                          alt={`Foto do alerta ${idx + 1}`}
                          className="w-20 h-16 rounded-lg object-cover border border-border"
                        />
                      ))}
                    </div>
                  )}
                  <div className="mt-2 flex items-center gap-1 text-[10px] text-muted-foreground">
                    <MessageCircle className="h-3 w-3" />
                    {alert.reports} confirmações
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default AlertasPage;
