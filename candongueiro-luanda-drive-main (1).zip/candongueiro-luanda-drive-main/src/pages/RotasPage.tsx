import { useState } from "react";
import { motion } from "framer-motion";
import AiRoutes from "@/components/AiRoutes";
import { Navigation, MapPin, Car, Clock, ExternalLink, Filter } from "lucide-react";

const ZONES = ["Todas", "Viana", "Cacuaco", "Cazenga", "Kilamba", "Benfica", "Rangel", "Maianga", "Mutamba", "São Paulo", "Maculusso", "Cidade Alta"];

const ACTIVE_ROUTES = [
  { id: 1, driver: "João M.", from: "Viana", to: "Mutamba", via: "Estrada de Catete", price: "250 Kz", seats: 4, time: "5 min", active: true },
  { id: 2, driver: "Pedro S.", from: "Cacuaco", to: "Maianga", via: "Via Expresso", price: "300 Kz", seats: 2, time: "3 min", active: true },
  { id: 3, driver: "Manuel A.", from: "Cazenga", to: "Cidade Alta", via: "Av. Hoji Ya Henda", price: "200 Kz", seats: 6, time: "8 min", active: true },
  { id: 4, driver: "Carlos R.", from: "Kilamba", to: "Largo 1º de Maio", via: "Autoestrada Luanda-Viana", price: "350 Kz", seats: 3, time: "2 min", active: true },
  { id: 5, driver: "António L.", from: "Benfica", to: "São Paulo", via: "Estrada do Golfe", price: "200 Kz", seats: 5, time: "10 min", active: true },
  { id: 6, driver: "Francisco T.", from: "Rangel", to: "Maculusso", via: "Rua da Missão", price: "150 Kz", seats: 1, time: "1 min", active: true },
];

const RotasPage = () => {
  const [selectedZone, setSelectedZone] = useState("Todas");
  const [searchText, setSearchText] = useState("");

  const filtered = ACTIVE_ROUTES.filter((r) => {
    const matchZone = selectedZone === "Todas" || r.from === selectedZone || r.to === selectedZone;
    const matchSearch =
      !searchText ||
      r.from.toLowerCase().includes(searchText.toLowerCase()) ||
      r.to.toLowerCase().includes(searchText.toLowerCase()) ||
      r.via.toLowerCase().includes(searchText.toLowerCase());
    return matchZone && matchSearch;
  });

  return (
    <div className="container py-6">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="font-display font-bold text-2xl text-foreground mb-1 flex items-center gap-2">
          <Navigation className="h-6 w-6 text-primary" />
          Rotas Activas
        </h1>
        <p className="text-muted-foreground text-sm mb-6">
          Veja os táxis disponíveis em tempo real e as rotas que estão a fazer
        </p>
      </motion.div>

      <div className="mb-6"><AiRoutes /></div>

      {/* Search */}
      <div className="relative mb-4">
        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Procurar por zona ou via..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          className="w-full pl-10 pr-4 py-3 rounded-lg bg-card text-foreground placeholder:text-muted-foreground text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
      </div>

      {/* Zone filters */}
      <div className="flex gap-2 overflow-x-auto pb-3 mb-4 scrollbar-hide">
        {ZONES.map((zone) => (
          <button
            key={zone}
            onClick={() => setSelectedZone(zone)}
            className={`whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
              selectedZone === zone
                ? "gradient-primary text-primary-foreground"
                : "bg-card text-muted-foreground border border-border hover:border-primary/30"
            }`}
          >
            {zone}
          </button>
        ))}
      </div>

      {/* Results */}
      <div className="space-y-3">
        {filtered.map((route, i) => (
          <motion.div
            key={route.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 * i }}
            className="p-4 rounded-xl bg-card border border-border hover:border-primary/20 transition-all"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full gradient-primary flex items-center justify-center">
                  <Car className="h-4 w-4 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">{route.driver}</p>
                  <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" /> Há {route.time}
                  </p>
                </div>
              </div>
              <span className="px-2 py-1 rounded-full bg-accent text-accent-foreground text-xs font-bold">
                {route.price}
              </span>
            </div>

            <div className="flex items-center gap-3 mb-3">
              <div className="flex flex-col items-center gap-0.5">
                <div className="w-2.5 h-2.5 rounded-full bg-success" />
                <div className="w-0.5 h-4 bg-border" />
                <div className="w-2.5 h-2.5 rounded-full bg-destructive" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-foreground font-medium">{route.from}</p>
                <p className="text-xs text-muted-foreground">via {route.via}</p>
                <p className="text-sm text-foreground font-medium">{route.to}</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">
                {route.seats} lugares disponíveis
              </span>
              <button
                onClick={() => {
                  window.open(
                    `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(route.from + ", Luanda")}&destination=${encodeURIComponent(route.to + ", Luanda")}`,
                    "_blank"
                  );
                }}
                className="flex items-center gap-1 text-xs font-medium text-primary hover:underline"
              >
                <ExternalLink className="h-3 w-3" />
                Ver no Mapa
              </button>
            </div>
          </motion.div>
        ))}

        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Navigation className="h-10 w-10 mx-auto mb-3 opacity-40" />
            <p className="text-sm">Nenhuma rota encontrada para esta zona</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default RotasPage;
