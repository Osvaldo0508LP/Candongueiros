import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Users, MessageCircle, Plus, MapPin, Search, Send, Car, UserCheck,
  Globe, ChevronRight, Hash, Crown, Clock, ThumbsUp, ArrowLeft
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

type CommunityType = "taxistas" | "passageiros" | "aluguer";
type ViewState = "list" | "chat";

interface Message {
  id: string;
  author: string;
  avatar: string;
  text: string;
  time: string;
  likes: number;
  isDriver?: boolean;
}

interface Community {
  id: string;
  name: string;
  type: CommunityType;
  zone?: string;
  members: number;
  messages: number;
  description: string;
  lastMessage?: string;
  isOfficial?: boolean;
}

const COMMUNITIES: Community[] = [
  {
    id: "geral-taxistas",
    name: "Taxistas de Luanda",
    type: "taxistas",
    members: 2340,
    messages: 15200,
    description: "Comunidade geral de todos os taxistas de Luanda. Partilhem alertas, dicas e apoiem-se.",
    lastMessage: "Cuidado na Av. Deolinda Rodrigues, muita operação hoje!",
    isOfficial: true,
  },
  {
    id: "viana",
    name: "Taxistas de Viana",
    type: "taxistas",
    zone: "Viana",
    members: 420,
    messages: 3100,
    description: "Grupo dos taxistas que fazem rotas em Viana e arredores.",
    lastMessage: "A via do Zango está livre agora.",
  },
  {
    id: "maianga",
    name: "Taxistas da Maianga",
    type: "taxistas",
    zone: "Maianga",
    members: 380,
    messages: 2800,
    description: "Comunidade dos taxistas da zona da Maianga.",
    lastMessage: "Preço para Mutamba subiu, atenção!",
  },
  {
    id: "cacuaco",
    name: "Taxistas de Cacuaco",
    type: "taxistas",
    zone: "Cacuaco",
    members: 310,
    messages: 2200,
    description: "Grupo de apoio dos taxistas de Cacuaco.",
    lastMessage: "Estrada do Sequele com obras, desviem.",
  },
  {
    id: "cazenga",
    name: "Taxistas do Cazenga",
    type: "taxistas",
    zone: "Cazenga",
    members: 290,
    messages: 1900,
    description: "Comunidade dos motoristas do Cazenga.",
    lastMessage: "Bom dia família, hoje o trânsito está calmo.",
  },
  {
    id: "kilamba",
    name: "Taxistas do Kilamba",
    type: "taxistas",
    zone: "Kilamba",
    members: 350,
    messages: 2600,
    description: "Grupo dos taxistas que operam no Kilamba Kiaxi.",
    lastMessage: "Nova paragem perto do mercado central.",
  },
  {
    id: "geral-passageiros",
    name: "Passageiros de Luanda",
    type: "passageiros",
    members: 5600,
    messages: 28000,
    description: "Comunidade geral dos passageiros. Partilhem experiências e fiquem actualizados sobre o táxi em Luanda.",
    lastMessage: "Alguém sabe se tem táxi para Viana agora?",
    isOfficial: true,
  },
  {
    id: "pass-viana",
    name: "Passageiros - Rota Viana",
    type: "passageiros",
    zone: "Viana",
    members: 890,
    messages: 5400,
    description: "Grupo dos passageiros que usam rotas de/para Viana.",
    lastMessage: "Tem táxi no Largo a fazer Viana!",
  },
  {
    id: "pass-cacuaco",
    name: "Passageiros - Rota Cacuaco",
    type: "passageiros",
    zone: "Cacuaco",
    members: 670,
    messages: 3900,
    description: "Passageiros que viajam para Cacuaco e arredores.",
    lastMessage: "Preço tá a 250kz hoje.",
  },
  {
    id: "aluguer-luanda",
    name: "Aluguer de Táxis - Luanda",
    type: "aluguer",
    members: 1200,
    messages: 8700,
    description: "Espaço para passageiros e taxistas negociarem aluguer de HiAce e viaturas para eventos e viagens.",
    lastMessage: "Preciso de HiAce para casamento sábado, alguém disponível?",
    isOfficial: true,
  },
  {
    id: "aluguer-eventos",
    name: "Aluguer para Eventos",
    type: "aluguer",
    members: 560,
    messages: 3200,
    description: "Grupo focado em aluguer de viaturas para eventos como casamentos, festas e excursões.",
    lastMessage: "Disponível HiAce 15 lugares, preço a combinar.",
  },
];

const SAMPLE_MESSAGES: Message[] = [
  { id: "1", author: "Manuel Costa", avatar: "MC", text: "Bom dia família! Cuidado na via do aeroporto, muita operação hoje.", time: "08:15", likes: 12, isDriver: true },
  { id: "2", author: "Ana Domingos", avatar: "AD", text: "Obrigada pelo aviso mano! Vou desviar pela Samba.", time: "08:22", likes: 5, isDriver: true },
  { id: "3", author: "Pedro Nzuzi", avatar: "PN", text: "Alguém a fazer Viana - Mutamba? Tenho 3 lugares livres.", time: "08:30", likes: 8, isDriver: true },
  { id: "4", author: "Teresa Lopes", avatar: "TL", text: "Precisava de um táxi para o Kilamba agora, alguém disponível?", time: "08:35", likes: 3 },
  { id: "5", author: "João Baptista", avatar: "JB", text: "Eu estou no Largo, posso passar pelo Kilamba. Manda localização!", time: "08:37", likes: 6, isDriver: true },
  { id: "6", author: "Rosa Mateus", avatar: "RM", text: "O trânsito na marginal está muito pesado, evitem essa via.", time: "08:45", likes: 15, isDriver: true },
  { id: "7", author: "Carlos Silva", avatar: "CS", text: "Boas notícias: a estrada do Zango já reabriu depois das obras! 🎉", time: "09:00", likes: 22, isDriver: true },
  { id: "8", author: "Luísa Fernandes", avatar: "LF", text: "Alguém tem HiAce disponível para sábado? Evento em Talatona.", time: "09:10", likes: 4 },
];

const ComunidadePage = () => {
  const [activeTab, setActiveTab] = useState<CommunityType>("taxistas");
  const [viewState, setViewState] = useState<ViewState>("list");
  const [selectedCommunity, setSelectedCommunity] = useState<Community | null>(null);
  const [messages, setMessages] = useState<Message[]>(SAMPLE_MESSAGES);
  const [newMessage, setNewMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [newGroupZone, setNewGroupZone] = useState("");
  const [newGroupDesc, setNewGroupDesc] = useState("");

  const filteredCommunities = COMMUNITIES.filter(
    (c) => c.type === activeTab && (searchQuery === "" || c.name.toLowerCase().includes(searchQuery.toLowerCase()) || (c.zone && c.zone.toLowerCase().includes(searchQuery.toLowerCase())))
  );

  const openCommunity = (community: Community) => {
    setSelectedCommunity(community);
    setViewState("chat");
  };

  const sendMessage = () => {
    if (!newMessage.trim()) return;
    const msg: Message = {
      id: Date.now().toString(),
      author: "Você",
      avatar: "EU",
      text: newMessage,
      time: new Date().toLocaleTimeString("pt-AO", { hour: "2-digit", minute: "2-digit" }),
      likes: 0,
    };
    setMessages([...messages, msg]);
    setNewMessage("");
    toast.success("Mensagem enviada!");
  };

  const handleCreateGroup = () => {
    if (!newGroupName.trim()) {
      toast.error("Coloque o nome do grupo");
      return;
    }
    toast.success(`Grupo "${newGroupName}" criado com sucesso!`);
    setCreateOpen(false);
    setNewGroupName("");
    setNewGroupZone("");
    setNewGroupDesc("");
  };

  const typeConfig = {
    taxistas: { icon: Car, label: "Taxistas", color: "bg-primary text-primary-foreground" },
    passageiros: { icon: Users, label: "Passageiros", color: "bg-secondary text-secondary-foreground" },
    aluguer: { icon: UserCheck, label: "Aluguer", color: "bg-accent text-accent-foreground" },
  };

  return (
    <div className="container max-w-2xl mx-auto px-4 py-6 space-y-6">
      <AnimatePresence mode="wait">
        {viewState === "list" ? (
          <motion.div key="list" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
            {/* Header */}
            <div>
              <h1 className="text-2xl font-display font-bold text-foreground">Comunidade</h1>
              <p className="text-sm text-muted-foreground mt-1">Conecte-se com taxistas e passageiros de Luanda</p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "Taxistas", value: "2.3K+", icon: Car },
                { label: "Passageiros", value: "5.6K+", icon: Users },
                { label: "Grupos", value: COMMUNITIES.length.toString(), icon: Hash },
              ].map((s) => (
                <Card key={s.label} className="text-center">
                  <CardContent className="p-3">
                    <s.icon className="h-5 w-5 mx-auto text-primary mb-1" />
                    <p className="text-lg font-bold text-foreground">{s.value}</p>
                    <p className="text-[10px] text-muted-foreground">{s.label}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as CommunityType)}>
              <TabsList className="w-full">
                <TabsTrigger value="taxistas" className="flex-1 text-xs gap-1">
                  <Car className="h-3.5 w-3.5" /> Taxistas
                </TabsTrigger>
                <TabsTrigger value="passageiros" className="flex-1 text-xs gap-1">
                  <Users className="h-3.5 w-3.5" /> Passageiros
                </TabsTrigger>
                <TabsTrigger value="aluguer" className="flex-1 text-xs gap-1">
                  <UserCheck className="h-3.5 w-3.5" /> Aluguer
                </TabsTrigger>
              </TabsList>
            </Tabs>

            {/* Search + Create */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Pesquisar grupo ou zona..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9" />
              </div>
              <Dialog open={createOpen} onOpenChange={setCreateOpen}>
                <DialogTrigger asChild>
                  <Button size="icon" className="gradient-primary shrink-0">
                    <Plus className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Criar Novo Grupo</DialogTitle>
                    <DialogDescription>Crie um grupo para a sua zona ou comunidade</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 pt-2">
                    <div>
                      <Label>Nome do Grupo</Label>
                      <Input placeholder="Ex: Taxistas do Rangel" value={newGroupName} onChange={(e) => setNewGroupName(e.target.value)} className="mt-1" />
                    </div>
                    <div>
                      <Label>Zona (opcional)</Label>
                      <Input placeholder="Ex: Rangel, Sambizanga..." value={newGroupZone} onChange={(e) => setNewGroupZone(e.target.value)} className="mt-1" />
                    </div>
                    <div>
                      <Label>Descrição</Label>
                      <Textarea placeholder="Descreva o objectivo do grupo..." value={newGroupDesc} onChange={(e) => setNewGroupDesc(e.target.value)} className="mt-1" rows={3} />
                    </div>
                    <Button className="w-full gradient-primary" onClick={handleCreateGroup}>
                      <Plus className="h-4 w-4 mr-2" /> Criar Grupo
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {/* Community List */}
            <div className="space-y-3">
              {filteredCommunities.map((community, i) => (
                <motion.div key={community.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => openCommunity(community)}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${community.isOfficial ? "gradient-primary" : "bg-muted"}`}>
                          {community.type === "taxistas" ? <Car className={`h-5 w-5 ${community.isOfficial ? "text-primary-foreground" : "text-foreground"}`} /> : community.type === "passageiros" ? <Users className={`h-5 w-5 ${community.isOfficial ? "text-primary-foreground" : "text-foreground"}`} /> : <UserCheck className={`h-5 w-5 ${community.isOfficial ? "text-primary-foreground" : "text-foreground"}`} />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-sm text-foreground truncate">{community.name}</h3>
                            {community.isOfficial && (
                              <Badge variant="secondary" className="text-[10px] px-1.5 py-0 shrink-0">
                                <Crown className="h-2.5 w-2.5 mr-0.5" /> Oficial
                              </Badge>
                            )}
                          </div>
                          {community.zone && (
                            <div className="flex items-center gap-1 mt-0.5">
                              <MapPin className="h-3 w-3 text-muted-foreground" />
                              <span className="text-xs text-muted-foreground">{community.zone}</span>
                            </div>
                          )}
                          {community.lastMessage && (
                            <p className="text-xs text-muted-foreground mt-1 truncate">{community.lastMessage}</p>
                          )}
                          <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
                            <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {community.members}</span>
                            <span className="flex items-center gap-1"><MessageCircle className="h-3 w-3" /> {community.messages}</span>
                          </div>
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0 mt-1" />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        ) : (
          /* Chat View */
          <motion.div key="chat" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} className="flex flex-col h-[calc(100vh-8rem)]">
            {/* Chat Header */}
            <div className="flex items-center gap-3 pb-4 border-b border-border">
              <Button variant="ghost" size="icon" onClick={() => setViewState("list")} className="shrink-0">
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${selectedCommunity?.isOfficial ? "gradient-primary" : "bg-muted"}`}>
                {selectedCommunity?.type === "taxistas" ? <Car className={`h-4 w-4 ${selectedCommunity?.isOfficial ? "text-primary-foreground" : "text-foreground"}`} /> : <Users className={`h-4 w-4 ${selectedCommunity?.isOfficial ? "text-primary-foreground" : "text-foreground"}`} />}
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="font-semibold text-sm text-foreground truncate">{selectedCommunity?.name}</h2>
                <p className="text-[10px] text-muted-foreground">{selectedCommunity?.members} membros online</p>
              </div>
              {selectedCommunity?.zone && (
                <Badge variant="outline" className="text-[10px] shrink-0">
                  <MapPin className="h-2.5 w-2.5 mr-1" /> {selectedCommunity.zone}
                </Badge>
              )}
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto py-4 space-y-3">
              {messages.map((msg) => (
                <motion.div key={msg.id} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className={`flex gap-2.5 ${msg.author === "Você" ? "flex-row-reverse" : ""}`}>
                  <Avatar className="h-8 w-8 shrink-0">
                    <AvatarFallback className={`text-xs ${msg.isDriver ? "bg-primary/15 text-primary" : "bg-secondary/30 text-secondary-foreground"}`}>
                      {msg.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <div className={`max-w-[75%] ${msg.author === "Você" ? "text-right" : ""}`}>
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-xs font-semibold text-foreground">{msg.author}</span>
                      {msg.isDriver && (
                        <Badge variant="secondary" className="text-[8px] px-1 py-0">
                          <Car className="h-2 w-2 mr-0.5" /> Taxista
                        </Badge>
                      )}
                      <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                        <Clock className="h-2.5 w-2.5" /> {msg.time}
                      </span>
                    </div>
                    <div className={`rounded-xl px-3 py-2 text-sm ${msg.author === "Você" ? "gradient-primary text-primary-foreground" : "bg-muted text-foreground"}`}>
                      {msg.text}
                    </div>
                    <button className="flex items-center gap-1 mt-1 text-[10px] text-muted-foreground hover:text-primary transition-colors" onClick={() => {
                      setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, likes: m.likes + 1 } : m));
                    }}>
                      <ThumbsUp className="h-3 w-3" /> {msg.likes}
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Input */}
            <div className="flex items-center gap-2 pt-3 border-t border-border">
              <Input
                placeholder="Escreva a sua mensagem..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                className="flex-1"
              />
              <Button size="icon" className="gradient-primary shrink-0" onClick={sendMessage} disabled={!newMessage.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ComunidadePage;
