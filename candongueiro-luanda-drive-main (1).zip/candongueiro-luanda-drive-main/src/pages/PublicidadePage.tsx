import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Megaphone, Image, Clock, Wallet, Check, Phone,
  ArrowRight, Star, Eye, BarChart3, Upload, X, Shield
} from "lucide-react";

type AdStep = "info" | "create" | "preview" | "payment" | "success";

interface AdForm {
  companyName: string;
  contactPhone: string;
  contactEmail: string;
  adTitle: string;
  adDescription: string;
  adImage: string | null;
  duration: number;
  placement: string;
}

const PLACEMENTS = [
  { id: "home-banner", label: "Banner Página Inicial", price: 500, icon: Eye, desc: "Visível por todos os visitantes" },
  { id: "rotas-sidebar", label: "Lateral nas Rotas", price: 350, icon: BarChart3, desc: "Visível ao procurar rotas" },
  { id: "comunidade", label: "Dentro da Comunidade", price: 300, icon: Star, desc: "Visível nos chats e grupos" },
];

const DURATIONS = [
  { days: 1, label: "1 Dia", discount: 0 },
  { days: 3, label: "3 Dias", discount: 5 },
  { days: 7, label: "1 Semana", discount: 10 },
  { days: 14, label: "2 Semanas", discount: 15 },
  { days: 30, label: "1 Mês", discount: 20 },
];

const PublicidadePage = () => {
  const [step, setStep] = useState<AdStep>("info");
  const [form, setForm] = useState<AdForm>({
    companyName: "", contactPhone: "", contactEmail: "",
    adTitle: "", adDescription: "", adImage: null,
    duration: 1, placement: "home-banner",
  });

  const selectedPlacement = PLACEMENTS.find((p) => p.id === form.placement)!;
  const selectedDuration = DURATIONS.find((d) => d.days === form.duration)!;
  const basePrice = selectedPlacement.price * form.duration;
  const discount = basePrice * (selectedDuration.discount / 100);
  const totalPrice = basePrice - discount;

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setForm({ ...form, adImage: URL.createObjectURL(file) });
    }
  };

  return (
    <div className="container py-6 max-w-lg mx-auto">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="font-display font-bold text-2xl text-foreground mb-1 flex items-center gap-2">
          <Megaphone className="h-6 w-6 text-primary" />
          Publicidade
        </h1>
        <p className="text-muted-foreground text-sm mb-6">
          Promova o seu negócio para milhares de utilizadores em Luanda
        </p>
      </motion.div>

      {/* Progress */}
      {step !== "info" && step !== "success" && (
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
            <span>Criar</span><span>Pré-visualizar</span><span>Pagar</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <motion.div
              className="h-full gradient-gold rounded-full"
              animate={{ width: step === "create" ? "33%" : step === "preview" ? "66%" : "100%" }}
            />
          </div>
        </div>
      )}

      <AnimatePresence mode="wait">
        {/* INFO */}
        {step === "info" && (
          <motion.div key="info" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            {/* Stats */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              {[
                { value: "15K+", label: "Utilizadores diários" },
                { value: "50K+", label: "Visualizações/dia" },
                { value: "90%", label: "Taxa de alcance" },
              ].map((s) => (
                <div key={s.label} className="p-3 rounded-xl bg-card border border-border text-center">
                  <p className="font-display font-bold text-lg text-primary">{s.value}</p>
                  <p className="text-[10px] text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>

            {/* Placements */}
            <h3 className="font-display font-semibold text-foreground text-sm mb-3">Onde anunciar?</h3>
            <div className="space-y-3 mb-6">
              {PLACEMENTS.map((p) => (
                <div key={p.id} className="p-4 rounded-xl bg-card border border-border flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg gradient-gold flex items-center justify-center shrink-0">
                    <p.icon className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-foreground">{p.label}</p>
                    <p className="text-xs text-muted-foreground">{p.desc}</p>
                  </div>
                  <span className="text-sm font-bold text-primary whitespace-nowrap">{p.price} Kz/dia</span>
                </div>
              ))}
            </div>

            {/* Pricing */}
            <div className="p-4 rounded-xl bg-accent/30 border border-accent mb-6">
              <h3 className="font-display font-semibold text-foreground text-sm mb-2">💰 Tabela de Preços</h3>
              <div className="space-y-1">
                {DURATIONS.map((d) => (
                  <div key={d.days} className="flex justify-between text-xs">
                    <span className="text-foreground">{d.label}</span>
                    <span className="text-muted-foreground">
                      {d.discount > 0 ? `${d.discount}% desconto` : "Preço base"}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => setStep("create")}
              className="w-full gradient-gold text-primary-foreground py-3 rounded-lg font-semibold text-sm flex items-center justify-center gap-2"
            >
              Criar o Meu Anúncio <ArrowRight className="h-4 w-4" />
            </button>
          </motion.div>
        )}

        {/* CREATE */}
        {step === "create" && (
          <motion.div key="create" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <button onClick={() => setStep("info")} className="text-sm text-primary mb-4 hover:underline">← Voltar</button>
            <div className="p-5 rounded-xl bg-card border border-border space-y-4">
              <h2 className="font-display font-semibold text-foreground text-sm">Dados da Empresa</h2>
              <div className="space-y-3">
                <input type="text" placeholder="Nome da empresa" value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none" />
                <input type="tel" placeholder="Telefone de contacto" value={form.contactPhone} onChange={(e) => setForm({ ...form, contactPhone: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none" />
                <input type="email" placeholder="Email (opcional)" value={form.contactEmail} onChange={(e) => setForm({ ...form, contactEmail: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none" />
              </div>

              <h2 className="font-display font-semibold text-foreground text-sm pt-2">Conteúdo do Anúncio</h2>
              <div className="space-y-3">
                <input type="text" placeholder="Título do anúncio" value={form.adTitle} onChange={(e) => setForm({ ...form, adTitle: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none" />
                <textarea placeholder="Descrição do produto/serviço" value={form.adDescription} onChange={(e) => setForm({ ...form, adDescription: e.target.value })} rows={3}
                  className="w-full px-3 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:ring-2 focus:ring-primary/30 focus:outline-none resize-none" />

                {/* Image upload */}
                {form.adImage ? (
                  <div className="relative rounded-lg overflow-hidden">
                    <img src={form.adImage} alt="Anúncio" className="w-full h-40 object-cover rounded-lg" />
                    <button onClick={() => setForm({ ...form, adImage: null })} className="absolute top-2 right-2 p-1 rounded-full bg-card/80 backdrop-blur-sm">
                      <X className="h-4 w-4 text-foreground" />
                    </button>
                  </div>
                ) : (
                  <label className="flex flex-col items-center justify-center p-6 rounded-lg border-2 border-dashed border-border hover:border-primary/30 cursor-pointer transition-colors">
                    <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                    <span className="text-sm text-muted-foreground">Carregar imagem do anúncio</span>
                    <span className="text-xs text-muted-foreground mt-1">JPG, PNG até 5MB</span>
                    <input type="file" accept="image/*" onChange={handleImageSelect} className="hidden" />
                  </label>
                )}
              </div>

              {/* Placement */}
              <h2 className="font-display font-semibold text-foreground text-sm pt-2">Posição</h2>
              <div className="space-y-2">
                {PLACEMENTS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setForm({ ...form, placement: p.id })}
                    className={`w-full p-3 rounded-lg text-left text-sm flex items-center justify-between transition-all ${
                      form.placement === p.id
                        ? "bg-primary/10 border-2 border-primary text-foreground"
                        : "bg-muted border border-border text-muted-foreground hover:border-primary/30"
                    }`}
                  >
                    <span>{p.label}</span>
                    <span className="font-bold text-primary">{p.price} Kz/dia</span>
                  </button>
                ))}
              </div>

              {/* Duration */}
              <h2 className="font-display font-semibold text-foreground text-sm pt-2">Duração</h2>
              <div className="flex flex-wrap gap-2">
                {DURATIONS.map((d) => (
                  <button
                    key={d.days}
                    onClick={() => setForm({ ...form, duration: d.days })}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                      form.duration === d.days
                        ? "gradient-gold text-primary-foreground"
                        : "bg-muted text-muted-foreground border border-border"
                    }`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>

              <button onClick={() => setStep("preview")} className="w-full gradient-gold text-primary-foreground py-3 rounded-lg font-semibold text-sm flex items-center justify-center gap-2">
                Pré-visualizar <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </motion.div>
        )}

        {/* PREVIEW */}
        {step === "preview" && (
          <motion.div key="preview" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <button onClick={() => setStep("create")} className="text-sm text-primary mb-4 hover:underline">← Voltar</button>
            <div className="space-y-4">
              <h2 className="font-display font-semibold text-foreground text-sm">Pré-visualização do Anúncio</h2>

              {/* Ad preview card */}
              <div className="rounded-xl overflow-hidden border border-border bg-card">
                {form.adImage && (
                  <img src={form.adImage} alt="Anúncio" className="w-full h-40 object-cover" />
                )}
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-[10px] px-2 py-0.5 rounded-full gradient-gold text-primary-foreground font-medium">Patrocinado</span>
                    <span className="text-[10px] text-muted-foreground">{form.companyName}</span>
                  </div>
                  <h3 className="font-display font-bold text-foreground text-sm">{form.adTitle || "Título do anúncio"}</h3>
                  <p className="text-xs text-muted-foreground mt-1">{form.adDescription || "Descrição do anúncio"}</p>
                </div>
              </div>

              {/* Summary */}
              <div className="p-4 rounded-xl bg-card border border-border space-y-2">
                <div className="flex justify-between text-sm"><span className="text-muted-foreground">Posição</span><span className="text-foreground font-medium">{selectedPlacement.label}</span></div>
                <div className="flex justify-between text-sm"><span className="text-muted-foreground">Duração</span><span className="text-foreground font-medium">{selectedDuration.label}</span></div>
                <div className="flex justify-between text-sm"><span className="text-muted-foreground">Preço base</span><span className="text-foreground">{basePrice.toLocaleString()} Kz</span></div>
                {discount > 0 && (
                  <div className="flex justify-between text-sm"><span className="text-muted-foreground">Desconto</span><span className="text-[hsl(var(--success))] font-medium">-{discount.toLocaleString()} Kz</span></div>
                )}
                <div className="h-px bg-border" />
                <div className="flex justify-between text-sm font-bold"><span className="text-foreground">Total</span><span className="text-primary">{totalPrice.toLocaleString()} Kz</span></div>
              </div>

              <button onClick={() => setStep("payment")} className="w-full gradient-gold text-primary-foreground py-3 rounded-lg font-semibold text-sm flex items-center justify-center gap-2">
                Ir para Pagamento <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </motion.div>
        )}

        {/* PAYMENT */}
        {step === "payment" && (
          <motion.div key="payment" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <button onClick={() => setStep("preview")} className="text-sm text-primary mb-4 hover:underline">← Voltar</button>
            <div className="p-5 rounded-xl bg-card border border-border space-y-4">
              <h2 className="font-display font-semibold text-foreground flex items-center gap-2">
                <Wallet className="h-5 w-5 text-primary" />
                Pagamento
              </h2>

              <div className="p-4 rounded-lg bg-accent/30 border border-accent text-center">
                <p className="text-xs text-muted-foreground mb-1">Total a pagar</p>
                <p className="font-display font-bold text-2xl text-primary">{totalPrice.toLocaleString()} Kz</p>
              </div>

              <div className="space-y-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Pagar via Unitel Money</p>
                <div className="p-4 rounded-lg bg-muted border border-border space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-[hsl(25,90%,50%)] flex items-center justify-center">
                      <Phone className="h-5 w-5 text-primary-foreground" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-foreground">Unitel Money</p>
                      <p className="text-xs text-muted-foreground">Enviar para: <span className="font-bold text-foreground">937 145 467</span></p>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-card border border-border">
                    <p className="text-xs text-muted-foreground mb-1">Instruções:</p>
                    <ol className="text-xs text-foreground space-y-1 list-decimal list-inside">
                      <li>Abra o Unitel Money no seu telemóvel</li>
                      <li>Envie <span className="font-bold text-primary">{totalPrice.toLocaleString()} Kz</span> para <span className="font-bold">937 145 467</span></li>
                      <li>Na descrição, coloque: <span className="font-bold text-primary">PUB-{form.companyName.substring(0, 8).toUpperCase()}</span></li>
                      <li>Após enviar, clique em "Confirmar Pagamento"</li>
                    </ol>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 p-3 rounded-lg bg-accent/30 border border-accent">
                <Shield className="h-4 w-4 text-primary shrink-0" />
                <p className="text-xs text-foreground">O seu anúncio será activado após confirmação do pagamento (até 24h).</p>
              </div>

              <button onClick={() => setStep("success")} className="w-full gradient-gold text-primary-foreground py-3 rounded-lg font-semibold text-sm">
                Confirmar Pagamento
              </button>
            </div>
          </motion.div>
        )}

        {/* SUCCESS */}
        {step === "success" && (
          <motion.div key="success" initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center py-12">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
              className="w-20 h-20 rounded-full bg-[hsl(var(--success))]/10 flex items-center justify-center mx-auto mb-4"
            >
              <Check className="h-10 w-10 text-[hsl(var(--success))]" />
            </motion.div>
            <h2 className="font-display font-bold text-2xl text-foreground mb-2">Anúncio Submetido! 🎉</h2>
            <p className="text-muted-foreground text-sm mb-1">O seu anúncio será activado após confirmação do pagamento.</p>
            <p className="text-xs text-muted-foreground mb-6">Receberá uma notificação no número {form.contactPhone || "registado"}.</p>
            <button onClick={() => { setStep("info"); setForm({ companyName: "", contactPhone: "", contactEmail: "", adTitle: "", adDescription: "", adImage: null, duration: 1, placement: "home-banner" }); }}
              className="gradient-gold text-primary-foreground px-6 py-2.5 rounded-lg text-sm font-semibold">
              Criar Outro Anúncio
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default PublicidadePage;
