import { useState } from "react";
import { motion } from "framer-motion";
import { Car, Phone, MapPin, Users, Calendar, DollarSign, Star, MessageCircle } from "lucide-react";

interface RentalVehicle {
  id: number;
  driver: string;
  vehicle: string;
  type: "hiace" | "viatura";
  capacity: number;
  pricePerDay: string;
  pricePerTrip: string;
  location: string;
  rating: number;
  phone: string;
  available: boolean;
  photo: string;
}

const VEHICLES: RentalVehicle[] = [
  { id: 1, driver: "António Silva", vehicle: "Toyota HiAce 2018", type: "hiace", capacity: 15, pricePerDay: "80.000 Kz", pricePerTrip: "25.000 Kz", location: "Viana", rating: 4.8, phone: "+244 923 456 789", available: true, photo: "🚐" },
  { id: 2, driver: "Maria Santos", vehicle: "Toyota HiAce 2020", type: "hiace", capacity: 14, pricePerDay: "100.000 Kz", pricePerTrip: "30.000 Kz", location: "Cacuaco", rating: 4.9, phone: "+244 912 345 678", available: true, photo: "🚐" },
  { id: 3, driver: "José Domingos", vehicle: "Toyota Corolla 2019", type: "viatura", capacity: 4, pricePerDay: "45.000 Kz", pricePerTrip: "15.000 Kz", location: "Maianga", rating: 4.5, phone: "+244 945 678 901", available: true, photo: "🚗" },
  { id: 4, driver: "Paulo Mendes", vehicle: "Toyota HiAce 2017", type: "hiace", capacity: 15, pricePerDay: "70.000 Kz", pricePerTrip: "20.000 Kz", location: "Kilamba", rating: 4.6, phone: "+244 934 567 890", available: false, photo: "🚐" },
  { id: 5, driver: "Fernando Costa", vehicle: "Hyundai H1 2021", type: "hiace", capacity: 12, pricePerDay: "90.000 Kz", pricePerTrip: "28.000 Kz", location: "Benfica", rating: 4.7, phone: "+244 956 789 012", available: true, photo: "🚐" },
  { id: 6, driver: "Carlos Neto", vehicle: "Toyota Fortuner 2020", type: "viatura", capacity: 7, pricePerDay: "60.000 Kz", pricePerTrip: "20.000 Kz", location: "Maculusso", rating: 4.4, phone: "+244 967 890 123", available: true, photo: "🚗" },
];

const AluguerPage = () => {
  const [typeFilter, setTypeFilter] = useState<"all" | "hiace" | "viatura">("all");
  const [showContact, setShowContact] = useState<number | null>(null);

  const filtered = typeFilter === "all" ? VEHICLES : VEHICLES.filter((v) => v.type === typeFilter);

  return (
    <div className="container py-6">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="font-display font-bold text-2xl text-foreground mb-1 flex items-center gap-2">
          <Car className="h-6 w-6 text-primary" />
          Aluguer de Viaturas
        </h1>
        <p className="text-muted-foreground text-sm mb-6">
          HiAce e viaturas disponíveis para eventos, casamentos, excursões e mais
        </p>
      </motion.div>

      {/* Type filter */}
      <div className="flex gap-2 mb-6">
        {[
          { key: "all", label: "Todos" },
          { key: "hiace", label: "🚐 HiAce / Minibus" },
          { key: "viatura", label: "🚗 Viaturas" },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setTypeFilter(f.key as typeof typeFilter)}
            className={`px-4 py-2 rounded-full text-xs font-medium transition-colors ${
              typeFilter === f.key
                ? "gradient-primary text-primary-foreground"
                : "bg-card text-muted-foreground border border-border hover:border-primary/30"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Vehicle list */}
      <div className="grid sm:grid-cols-2 gap-4">
        {filtered.map((vehicle, i) => (
          <motion.div
            key={vehicle.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 * i }}
            className={`p-5 rounded-xl bg-card border transition-all ${
              vehicle.available ? "border-border hover:border-primary/20" : "border-border opacity-60"
            }`}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{vehicle.photo}</span>
                <div>
                  <h3 className="text-sm font-semibold text-foreground">{vehicle.vehicle}</h3>
                  <p className="text-xs text-muted-foreground">{vehicle.driver}</p>
                </div>
              </div>
              <span
                className={`px-2 py-1 rounded-full text-[10px] font-semibold ${
                  vehicle.available
                    ? "bg-success/10 text-success"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {vehicle.available ? "Disponível" : "Ocupado"}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Users className="h-3 w-3" />
                {vehicle.capacity} lugares
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <MapPin className="h-3 w-3" />
                {vehicle.location}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Star className="h-3 w-3 text-secondary" />
                {vehicle.rating}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Calendar className="h-3 w-3" />
                Aluguer
              </div>
            </div>

            <div className="flex items-center gap-3 mb-3 p-3 rounded-lg bg-muted">
              <div className="text-center flex-1">
                <p className="text-[10px] text-muted-foreground">Por dia</p>
                <p className="text-sm font-bold text-foreground">{vehicle.pricePerDay}</p>
              </div>
              <div className="w-px h-8 bg-border" />
              <div className="text-center flex-1">
                <p className="text-[10px] text-muted-foreground">Por viagem</p>
                <p className="text-sm font-bold text-foreground">{vehicle.pricePerTrip}</p>
              </div>
            </div>

            {vehicle.available && (
              <div>
                {showContact === vehicle.id ? (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2">
                    <a
                      href={`tel:${vehicle.phone}`}
                      className="w-full gradient-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold flex items-center justify-center gap-2"
                    >
                      <Phone className="h-4 w-4" />
                      {vehicle.phone}
                    </a>
                    <a
                      href={`https://wa.me/${vehicle.phone.replace(/\s/g, "").replace("+", "")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full bg-success text-primary-foreground py-2.5 rounded-lg text-sm font-semibold flex items-center justify-center gap-2"
                    >
                      <MessageCircle className="h-4 w-4" />
                      WhatsApp
                    </a>
                  </motion.div>
                ) : (
                  <button
                    onClick={() => setShowContact(vehicle.id)}
                    className="w-full gradient-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold flex items-center justify-center gap-2"
                  >
                    <Phone className="h-4 w-4" />
                    Contactar
                  </button>
                )}
              </div>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default AluguerPage;
