import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Users, Plus, HeartHandshake, Gift, Ban, Megaphone, Bus, Send, Crown, UserMinus, LogOut, X, Check, Phone } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, displayName, timeAgo } from "@/hooks/useAuth";

const KINDS: Record<string, { label: string; icon: typeof Users }> = {
  vaquinha: { label: "Vaquinha", icon: HeartHandshake },
  free_ride: { label: "Viagem grátis", icon: Gift },
  strike: { label: "Greve", icon: Ban },
  notice: { label: "Aviso geral", icon: Megaphone },
  support: { label: "Apoio", icon: Users },
  ride_pool: { label: "Viagem em grupo", icon: Bus },
};

type Group = {
  id: string; owner_id: string; owner_name: string; audience: string; kind: string; title: string;
  description: string | null; zone: string | null; departure_zone: string | null; destination: string | null;
  travel_at: string | null; seats: number | null; goal_kz: number | null; raised_kz: number; status: string; created_at: string;
};
type Member = { group_id: string; user_id: string; member_name: string; role: string };
type Offer = { id: string; group_id: string; driver_id: string; driver_name: string; price_kz: number; phone: string | null; message: string | null; status: string };
type Post = { id: string; user_id: string; author_name: string; content: string; created_at: string };

const input = "w-full px-3 py-2.5 rounded-lg bg-muted text-foreground text-sm border border-border";

const GruposPage = () => {
  const { user, profile } = useAuth();
  const me = displayName(profile, user);
  const [tab, setTab] = useState<"apoio" | "viagens" | "mural" | "meus">("apoio");
  const [groups, setGroups] = useState<Group[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [g, m, o] = await Promise.all([
      supabase.from("groups").select("*").order("created_at", { ascending: false }).limit(200),
      supabase.from("group_members").select("group_id,user_id,member_name,role"),
      supabase.from("ride_offers").select("*").order("created_at", { ascending: false }),
    ]);
    setGroups((g.data as Group[]) || []);
    setMembers((m.data as Member[]) || []);
    setOffers((o.data as Offer[]) || []);
  }, []);

  useEffect(() => {
    load();
    const ch = supabase.channel("grupos")
      .on("postgres_changes", { event: "*", schema: "public", table: "groups" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "group_members" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "ride_offers" }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [load]);

  const countOf = (id: string) => members.filter((m) => m.group_id === id).length;
  const list = groups.filter((g) => {
    if (tab === "apoio") return g.kind !== "ride_pool";
    if (tab === "viagens") return g.kind === "ride_pool";
    if (tab === "mural") return g.kind === "ride_pool" && g.status !== "closed";
    return members.some((m) => m.group_id === g.id && m.user_id === user?.id);
  });
  const open = groups.find((g) => g.id === openId) || null;

  return (
    <div className="container py-6 max-w-3xl">
      <div className="flex items-center justify-between mb-1">
        <h1 className="font-display font-bold text-2xl text-foreground flex items-center gap-2"><Users className="h-6 w-6 text-primary" /> Grupos</h1>
        {user ? (
          <button onClick={() => setShowCreate(true)} className="gradient-primary text-primary-foreground px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1"><Plus className="h-3.5 w-3.5" /> Criar grupo</button>
        ) : (
          <Link to="/entrar" className="gradient-primary text-primary-foreground px-3 py-2 rounded-lg text-xs font-semibold">Entrar</Link>
        )}
      </div>
      <p className="text-muted-foreground text-sm mb-4">Vaquinhas, avisos, greves e viagens em grupo para passageiros e taxistas.</p>

      <div className="flex gap-2 overflow-x-auto pb-3 mb-3">
        {([["apoio", "Apoio & Anúncios"], ["viagens", "Viagens em Grupo"], ["mural", "Mural dos Taxistas"], ["meus", "Meus grupos"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-medium ${tab === k ? "gradient-primary text-primary-foreground" : "bg-card text-muted-foreground border border-border"}`}>{l}</button>
        ))}
      </div>

      {tab === "mural" && (
        <p className="text-xs text-muted-foreground mb-3 p-3 rounded-lg bg-card border border-border">Pedidos de passageiros que querem alugar um táxi em grupo. Taxistas: avaliem e enviem a vossa proposta.</p>
      )}

      <div className="grid sm:grid-cols-2 gap-3">
        {list.length === 0 && <p className="text-sm text-muted-foreground col-span-full text-center py-10">Nenhum grupo ainda.</p>}
        {list.map((g) => {
          const K = KINDS[g.kind]; const n = countOf(g.id);
          return (
            <motion.button key={g.id} layout onClick={() => setOpenId(g.id)} className="text-left p-4 rounded-xl bg-card border border-border hover:border-primary/40">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center"><K.icon className="h-4 w-4 text-primary-foreground" /></div>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-muted text-muted-foreground">{K.label}</span>
                <span className="text-[10px] text-muted-foreground capitalize">· {g.audience}s</span>
                {g.status === "full" && <span className="ml-auto text-[10px] font-semibold px-2 py-0.5 rounded-full bg-success text-primary-foreground">Completo</span>}
              </div>
              <h3 className="text-sm font-semibold text-foreground">{g.title}</h3>
              {g.kind === "ride_pool" && <p className="text-xs text-muted-foreground mt-1">{g.departure_zone} → {g.destination}{g.travel_at ? ` · ${new Date(g.travel_at).toLocaleString("pt-AO", { dateStyle: "short", timeStyle: "short" })}` : ""}</p>}
              {g.kind === "vaquinha" && g.goal_kz ? (
                <div className="mt-2"><div className="h-2 rounded-full bg-muted overflow-hidden"><div className="h-full gradient-gold" style={{ width: `${Math.min(100, (g.raised_kz / g.goal_kz) * 100)}%` }} /></div>
                  <p className="text-[10px] text-muted-foreground mt-1">{g.raised_kz.toLocaleString()} / {g.goal_kz.toLocaleString()} Kz</p></div>
              ) : null}
              <p className="text-[10px] text-muted-foreground mt-2">{g.kind === "ride_pool" ? `${n}/${g.seats} lugares` : `${n} membros`} · {offers.filter((o) => o.group_id === g.id).length > 0 && g.kind === "ride_pool" ? `${offers.filter((o) => o.group_id === g.id).length} propostas · ` : ""}{timeAgo(g.created_at)}</p>
            </motion.button>
          );
        })}
      </div>

      {showCreate && user && <CreateGroup onClose={() => setShowCreate(false)} userId={user.id} me={me} userType={profile?.user_type || "passageiro"} />}
      {open && <GroupDetail group={open} members={members.filter((m) => m.group_id === open.id)} offers={offers.filter((o) => o.group_id === open.id)} onClose={() => setOpenId(null)} me={me} />}
    </div>
  );
};

const Modal = ({ children, onClose }: { children: React.ReactNode; onClose: () => void }) => (
  <div className="fixed inset-0 z-[60] bg-foreground/50 flex items-end sm:items-center justify-center" onClick={onClose}>
    <motion.div initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} onClick={(e) => e.stopPropagation()} className="bg-card w-full sm:max-w-lg max-h-[90vh] overflow-y-auto rounded-t-2xl sm:rounded-2xl p-5 relative">
      <button onClick={onClose} className="absolute top-3 right-3 p-1 rounded-full hover:bg-muted"><X className="h-5 w-5" /></button>
      {children}
    </motion.div>
  </div>
);

const CreateGroup = ({ onClose, userId, me, userType }: { onClose: () => void; userId: string; me: string; userType: string }) => {
  const [f, setF] = useState({ kind: userType === "passageiro" ? "ride_pool" : "vaquinha", title: "", description: "", departure_zone: "", destination: "", travel_at: "", seats: 14, goal_kz: 50000, zone: "" });
  const [busy, setBusy] = useState(false);
  const save = async () => {
    if (!f.title.trim()) return toast.error("Dê um título ao grupo");
    if (f.kind === "ride_pool" && (!f.departure_zone || !f.destination || f.seats < 14)) return toast.error("Indique partida, destino e pelo menos 14 lugares");
    setBusy(true);
    const { error } = await supabase.from("groups").insert({
      owner_id: userId, owner_name: me, audience: userType === "taxista" ? "taxista" : "passageiro", kind: f.kind,
      title: f.title.trim(), description: f.description.trim() || null, zone: f.zone || null,
      departure_zone: f.kind === "ride_pool" ? f.departure_zone : null, destination: f.kind === "ride_pool" ? f.destination : null,
      travel_at: f.kind === "ride_pool" && f.travel_at ? new Date(f.travel_at).toISOString() : null,
      seats: f.kind === "ride_pool" ? f.seats : null, goal_kz: f.kind === "vaquinha" ? f.goal_kz : null,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Grupo criado! É o administrador.");
    onClose();
  };
  return (
    <Modal onClose={onClose}>
      <h2 className="font-display font-bold text-lg text-foreground mb-4">Criar grupo</h2>
      <div className="space-y-3">
        <div className="grid grid-cols-3 gap-2">
          {Object.entries(KINDS).map(([k, v]) => (
            <button key={k} onClick={() => setF({ ...f, kind: k })} className={`p-2 rounded-lg text-[11px] font-medium flex flex-col items-center gap-1 ${f.kind === k ? "gradient-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
              <v.icon className="h-4 w-4" />{v.label}
            </button>
          ))}
        </div>
        <input className={input} placeholder={f.kind === "vaquinha" ? "Ex: Vaquinha para apoiar o João" : f.kind === "ride_pool" ? "Ex: Grupo Zango → Mutamba sábado" : "Título"} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
        <textarea className={`${input} resize-none`} rows={3} placeholder="Descrição" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
        {f.kind === "vaquinha" && (<label className="block text-xs text-muted-foreground">Meta (Kz)<input type="number" min={1000} className={input} value={f.goal_kz} onChange={(e) => setF({ ...f, goal_kz: +e.target.value })} /></label>)}
        {f.kind === "ride_pool" && (
          <>
            <div className="grid grid-cols-2 gap-2">
              <input className={input} placeholder="Partida (zona)" value={f.departure_zone} onChange={(e) => setF({ ...f, departure_zone: e.target.value })} />
              <input className={input} placeholder="Destino" value={f.destination} onChange={(e) => setF({ ...f, destination: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input type="datetime-local" className={input} value={f.travel_at} onChange={(e) => setF({ ...f, travel_at: e.target.value })} />
              <label className="text-xs text-muted-foreground">Lugares (mín. 14)<input type="number" min={14} className={input} value={f.seats} onChange={(e) => setF({ ...f, seats: +e.target.value })} /></label>
            </div>
          </>
        )}
        {f.kind !== "ride_pool" && <input className={input} placeholder="Zona (opcional, ex: Viana)" value={f.zone} onChange={(e) => setF({ ...f, zone: e.target.value })} />}
        <button disabled={busy} onClick={save} className="w-full gradient-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold disabled:opacity-60">{busy ? "A criar..." : "Criar grupo"}</button>
      </div>
    </Modal>
  );
};

const GroupDetail = ({ group: g, members, offers, onClose, me }: { group: Group; members: Member[]; offers: Offer[]; onClose: () => void; me: string }) => {
  const { user, profile } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [msg, setMsg] = useState("");
  const [amount, setAmount] = useState(1000);
  const [offer, setOffer] = useState({ price: 0, phone: "", message: "" });
  const myRole = members.find((m) => m.user_id === user?.id)?.role;
  const isAdmin = myRole === "admin";
  const K = KINDS[g.kind];

  const loadPosts = useCallback(async () => {
    const { data } = await supabase.from("group_posts").select("id,user_id,author_name,content,created_at").eq("group_id", g.id).order("created_at");
    setPosts((data as Post[]) || []);
  }, [g.id]);
  useEffect(() => {
    loadPosts();
    const ch = supabase.channel(`posts-${g.id}`).on("postgres_changes", { event: "*", schema: "public", table: "group_posts", filter: `group_id=eq.${g.id}` }, loadPosts).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [g.id, loadPosts]);

  const need = () => { if (!user) { toast.error("Entre na sua conta primeiro"); return false; } return true; };
  const run = async (p: PromiseLike<{ error: { message: string } | null }>, ok?: string) => { const { error } = await p; if (error) toast.error(error.message); else if (ok) toast.success(ok); };

  const join = () => need() && run(supabase.from("group_members").insert({ group_id: g.id, user_id: user!.id, member_name: me }), "Entrou no grupo");
  const leave = () => run(supabase.from("group_members").delete().eq("group_id", g.id).eq("user_id", user!.id), "Saiu do grupo");
  const send = async () => { if (!msg.trim()) return; await run(supabase.from("group_posts").insert({ group_id: g.id, user_id: user!.id, author_name: me, content: msg.trim() })); setMsg(""); };
  const promote = (uid: string, role: string) => run(supabase.from("group_members").update({ role }).eq("group_id", g.id).eq("user_id", uid), "Actualizado");
  const kick = (uid: string) => run(supabase.from("group_members").delete().eq("group_id", g.id).eq("user_id", uid), "Membro removido");
  const contribute = () => need() && run(supabase.rpc("contribute_vaquinha", { _group_id: g.id, _amount: amount }), `Obrigado! ${amount} Kz registados. Envie via Unitel Money ou Multicaixa Express ao administrador.`);
  const promoteAd = () => run(supabase.from("announcements").insert({ group_id: g.id, created_by: user!.id, title: `${K.label}: ${g.title}`, body: g.description }), "Anúncio enviado para a área de publicidade");
  const closeGroup = () => run(supabase.from("groups").update({ status: g.status === "closed" ? "open" : "closed" }).eq("id", g.id), "Estado actualizado");
  const del = async () => { await run(supabase.from("groups").delete().eq("id", g.id), "Grupo eliminado"); onClose(); };
  const sendOffer = () => {
    if (!need()) return;
    if (offer.price <= 0) return toast.error("Indique o preço");
    run(supabase.from("ride_offers").insert({ group_id: g.id, driver_id: user!.id, driver_name: me, price_kz: offer.price, phone: offer.phone || null, message: offer.message || null }), "Proposta enviada");
  };
  const setOfferStatus = (id: string, status: string) => run(supabase.from("ride_offers").update({ status }).eq("id", id), status === "accepted" ? "Proposta aceite" : "Proposta rejeitada");

  return (
    <Modal onClose={onClose}>
      <div className="flex items-center gap-2 mb-1"><K.icon className="h-5 w-5 text-primary" /><span className="text-xs font-semibold text-muted-foreground">{K.label}</span></div>
      <h2 className="font-display font-bold text-lg text-foreground pr-8">{g.title}</h2>
      <p className="text-xs text-muted-foreground mb-2">Criado por {g.owner_name} · {timeAgo(g.created_at)}</p>
      {g.description && <p className="text-sm text-foreground mb-3">{g.description}</p>}
      {g.kind === "ride_pool" && (
        <div className="p-3 rounded-lg bg-muted text-sm mb-3 space-y-1">
          <p><b>{g.departure_zone}</b> → <b>{g.destination}</b></p>
          {g.travel_at && <p className="text-xs text-muted-foreground">{new Date(g.travel_at).toLocaleString("pt-AO")}</p>}
          <p className="text-xs">{members.length}/{g.seats} lugares {g.status === "full" && "· Grupo completo — visível no Mural dos Taxistas"}</p>
        </div>
      )}
      {g.kind === "vaquinha" && g.goal_kz && (
        <div className="mb-3">
          <div className="h-3 rounded-full bg-muted overflow-hidden"><div className="h-full gradient-gold" style={{ width: `${Math.min(100, (g.raised_kz / g.goal_kz) * 100)}%` }} /></div>
          <p className="text-xs text-muted-foreground mt-1">{g.raised_kz.toLocaleString()} de {g.goal_kz.toLocaleString()} Kz</p>
          <div className="flex gap-2 mt-2">
            <input type="number" min={100} value={amount} onChange={(e) => setAmount(+e.target.value)} className={input} />
            <button onClick={contribute} className="gradient-gold text-foreground px-4 rounded-lg text-sm font-semibold whitespace-nowrap">Contribuir</button>
          </div>
        </div>
      )}

      <div className="flex gap-2 flex-wrap mb-4">
        {!myRole && g.status !== "closed" && <button onClick={join} className="gradient-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-semibold">Juntar-me</button>}
        {myRole && !isAdmin && <button onClick={leave} className="px-4 py-2 rounded-lg text-sm border border-border flex items-center gap-1"><LogOut className="h-4 w-4" /> Sair</button>}
        {isAdmin && ["strike", "free_ride", "notice", "vaquinha"].includes(g.kind) && <button onClick={promoteAd} className="px-3 py-2 rounded-lg text-xs font-semibold bg-warning text-foreground flex items-center gap-1"><Megaphone className="h-3.5 w-3.5" /> Enviar para Publicidade</button>}
        {isAdmin && <button onClick={closeGroup} className="px-3 py-2 rounded-lg text-xs border border-border">{g.status === "closed" ? "Reabrir" : "Fechar grupo"}</button>}
        {isAdmin && <button onClick={del} className="px-3 py-2 rounded-lg text-xs bg-destructive text-destructive-foreground">Eliminar</button>}
      </div>

      {g.kind === "ride_pool" && (
        <div className="mb-4">
          <p className="font-semibold text-sm text-foreground mb-2">Propostas dos taxistas</p>
          {offers.length === 0 && <p className="text-xs text-muted-foreground">Ainda sem propostas.</p>}
          <div className="space-y-2">
            {offers.map((o) => (
              <div key={o.id} className="p-3 rounded-lg border border-border text-sm">
                <div className="flex justify-between"><b>{o.driver_name}</b><span className="font-bold text-primary">{o.price_kz.toLocaleString()} Kz</span></div>
                {o.message && <p className="text-xs text-muted-foreground">{o.message}</p>}
                <div className="flex items-center gap-2 mt-2">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${o.status === "accepted" ? "bg-success text-primary-foreground" : o.status === "rejected" ? "bg-destructive text-destructive-foreground" : "bg-muted"}`}>{o.status === "accepted" ? "Aceite" : o.status === "rejected" ? "Rejeitada" : "Pendente"}</span>
                  {o.phone && <a href={`https://wa.me/244${o.phone.replace(/\D/g, "")}`} target="_blank" rel="noreferrer" className="text-xs text-primary flex items-center gap-1"><Phone className="h-3 w-3" />WhatsApp</a>}
                  {isAdmin && o.status === "pending" && (<>
                    <button onClick={() => setOfferStatus(o.id, "accepted")} className="ml-auto p-1 rounded bg-success text-primary-foreground"><Check className="h-4 w-4" /></button>
                    <button onClick={() => setOfferStatus(o.id, "rejected")} className="p-1 rounded bg-destructive text-destructive-foreground"><X className="h-4 w-4" /></button>
                  </>)}
                </div>
              </div>
            ))}
          </div>
          {profile?.user_type === "taxista" && !isAdmin && (
            <div className="mt-3 p-3 rounded-lg bg-muted space-y-2">
              <p className="text-xs font-semibold">Fazer proposta</p>
              <div className="grid grid-cols-2 gap-2">
                <input type="number" placeholder="Preço total (Kz)" className={input} onChange={(e) => setOffer({ ...offer, price: +e.target.value })} />
                <input placeholder="Telefone" className={input} onChange={(e) => setOffer({ ...offer, phone: e.target.value })} />
              </div>
              <input placeholder="Mensagem (ex: HiAce 15 lugares)" className={input} onChange={(e) => setOffer({ ...offer, message: e.target.value })} />
              <button onClick={sendOffer} className="w-full gradient-primary text-primary-foreground py-2 rounded-lg text-sm font-semibold">Enviar proposta</button>
            </div>
          )}
        </div>
      )}

      <p className="font-semibold text-sm text-foreground mb-2">Membros ({members.length})</p>
      <div className="space-y-1 mb-4 max-h-40 overflow-y-auto">
        {members.map((m) => (
          <div key={m.user_id} className="flex items-center gap-2 text-sm">
            <span className="flex-1">{m.member_name}</span>
            {m.role === "admin" && <Crown className="h-3.5 w-3.5 text-warning" />}
            {isAdmin && m.user_id !== user?.id && (<>
              <button onClick={() => promote(m.user_id, m.role === "admin" ? "member" : "admin")} className="text-[10px] px-2 py-0.5 rounded bg-muted">{m.role === "admin" ? "Tirar admin" : "Tornar admin"}</button>
              <button onClick={() => kick(m.user_id)} className="text-destructive"><UserMinus className="h-4 w-4" /></button>
            </>)}
          </div>
        ))}
      </div>

      <p className="font-semibold text-sm text-foreground mb-2">Conversa</p>
      <div className="space-y-2 max-h-56 overflow-y-auto mb-2">
        {posts.length === 0 && <p className="text-xs text-muted-foreground">Sem mensagens.</p>}
        {posts.map((p) => (
          <div key={p.id} className={`p-2 rounded-lg text-sm ${p.user_id === user?.id ? "bg-accent ml-8" : "bg-muted mr-8"}`}>
            <p className="text-[10px] font-semibold text-muted-foreground">{p.author_name} · {timeAgo(p.created_at)}</p>
            <p className="text-foreground">{p.content}</p>
          </div>
        ))}
      </div>
      {myRole ? (
        <div className="flex gap-2">
          <input value={msg} onChange={(e) => setMsg(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Escrever mensagem..." className={input} />
          <button onClick={send} className="gradient-primary text-primary-foreground px-3 rounded-lg"><Send className="h-4 w-4" /></button>
        </div>
      ) : <p className="text-xs text-muted-foreground">Junte-se ao grupo para conversar.</p>}
    </Modal>
  );
};

export default GruposPage;
