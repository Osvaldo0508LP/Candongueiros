import { motion } from "framer-motion";
import { MapPin, Search, Navigation, AlertTriangle, Car, ArrowRight, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import taxiHero from "@/assets/taxi-hero.png";
import luandaCity from "@/assets/luanda-city.jpg";
import LuandaSlides from "@/components/LuandaSlides";
import AdBanner from "@/components/AdBanner";

const POPULAR_ROUTES = [
  { from: "Viana", to: "Cidade Alta", taxis: 12 },
  { from: "Cacuaco", to: "Maianga", taxis: 8 },
  { from: "Cazenga", to: "Mutamba", taxis: 15 },
  { from: "Kilamba", to: "Largo 1º de Maio", taxis: 6 },
  { from: "Benfica", to: "São Paulo", taxis: 10 },
  { from: "Rangel", to: "Maculusso", taxis: 9 },
  { from: "Zango", to: "Mutamba", taxis: 7 },
  { from: "Zango", to: "Viana", taxis: 11 },
  { from: "Aeroporto Novo (AIAAN)", to: "Cidade Alta", taxis: 5 },
  { from: "Viana", to: "Aeroporto Novo (AIAAN)", taxis: 4 },
];

const FEATURES = [
  {
    icon: Navigation,
    title: "Rotas em Tempo Real",
    desc: "Saiba quais táxis estão a fazer a sua rota agora",
    to: "/rotas",
    color: "gradient-primary",
  },
  {
    icon: AlertTriangle,
    title: "Alertas de Via",
    desc: "Operações, obstruções e trânsito reportado pela comunidade",
    to: "/alertas",
    color: "gradient-gold",
  },
  {
    icon: Car,
    title: "Aluguer de Viaturas",
    desc: "HiAce e viaturas para eventos e serviços especiais",
    to: "/aluguer",
    color: "gradient-primary",
  },
];

const HomePage = () => {
  const [searchFrom, setSearchFrom] = useState("");
  const [searchTo, setSearchTo] = useState("");

  const filteredRoutes = POPULAR_ROUTES.filter(
    (r) =>
      r.from.toLowerCase().includes(searchFrom.toLowerCase()) ||
      r.to.toLowerCase().includes(searchTo.toLowerCase()) ||
      (!searchFrom && !searchTo)
  );

  return (
    <div className="relative">
      {/* Full page background */}
      <div className="fixed inset-0 -z-10">
        <img src={luandaCity} alt="Cidade de Luanda" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" />
      </div>
      <section className="relative overflow-hidden gradient-hero">
        <div className="absolute inset-0 opacity-20">
          <img src={taxiHero} alt="Táxis de Luanda" className="w-full h-full object-cover" />
        </div>
        <div className="relative container py-12 md:py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-2xl"
          >
            <h1 className="text-3xl md:text-5xl font-display font-bold text-primary-foreground mb-4 leading-tight">
              O teu companheiro
              <br />
              <span className="text-secondary">nas ruas de Luanda</span>
            </h1>
            <p className="text-primary-foreground/80 text-lg mb-8 max-w-lg">
              Encontra táxis, descobre rotas alternativas e evita o trânsito.
              Para taxistas e passageiros.
            </p>
          </motion.div>

          {/* Search Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="glass-card rounded-xl p-5 max-w-xl taxi-shadow"
          >
            <p className="font-display font-semibold text-foreground mb-3 flex items-center gap-2">
              <Search className="h-4 w-4 text-primary" />
              Procurar Táxi
            </p>
            <div className="space-y-3">
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-success" />
                <input
                  type="text"
                  placeholder="De onde? (ex: Viana)"
                  value={searchFrom}
                  onChange={(e) => setSearchFrom(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-destructive" />
                <input
                  type="text"
                  placeholder="Para onde? (ex: Mutamba)"
                  value={searchTo}
                  onChange={(e) => setSearchTo(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>
              <button
                className="w-full gradient-primary text-primary-foreground py-3 rounded-lg font-semibold text-sm hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
                onClick={() => {
                  const query = `${searchFrom} para ${searchTo} Luanda Angola`;
                  window.open(`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(searchFrom + ", Luanda")}&destination=${encodeURIComponent(searchTo + ", Luanda")}`, "_blank");
                }}
              >
                <Navigation className="h-4 w-4" />
                Procurar Rota no Mapa
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="container pt-8">
        <LuandaSlides />
      </section>

      {/* Features */}
      <section className="container py-10">
        <div className="grid md:grid-cols-3 gap-4">
          {FEATURES.map((feat, i) => (
            <motion.div
              key={feat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * i + 0.4 }}
            >
              <Link
                to={feat.to}
                className="block p-5 rounded-xl bg-card border border-border hover:taxi-shadow hover:border-primary/20 transition-all group"
              >
                <div className={`w-10 h-10 rounded-lg ${feat.color} flex items-center justify-center mb-3`}>
                  <feat.icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <h3 className="font-display font-semibold text-foreground mb-1">{feat.title}</h3>
                <p className="text-sm text-muted-foreground">{feat.desc}</p>
                <div className="mt-3 flex items-center gap-1 text-primary text-sm font-medium group-hover:gap-2 transition-all">
                  Ver mais <ArrowRight className="h-4 w-4" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Ad Banner */}
      <section className="container pb-6">
        <AdBanner />
      </section>

      {/* Popular Routes */}
      <section className="container pb-10">
        <h2 className="font-display font-bold text-xl text-foreground mb-4 flex items-center gap-2">
          <Users className="h-5 w-5 text-primary" />
          Rotas Populares Agora
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredRoutes.map((route, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.05 * i }}
              className="p-4 rounded-xl bg-card border border-border hover:border-primary/30 transition-all"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="flex flex-col items-center gap-1">
                  <div className="w-3 h-3 rounded-full bg-success border-2 border-success/30" />
                  <div className="w-0.5 h-6 bg-border" />
                  <div className="w-3 h-3 rounded-full bg-destructive border-2 border-destructive/30" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">{route.from}</p>
                  <p className="text-xs text-muted-foreground my-1">→</p>
                  <p className="text-sm font-medium text-foreground">{route.to}</p>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-accent text-accent-foreground text-xs font-semibold">
                    <Car className="h-3 w-3" />
                    {route.taxis}
                  </span>
                  <p className="text-[10px] text-muted-foreground mt-1">táxis activos</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default HomePage;
