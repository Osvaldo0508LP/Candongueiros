import { useState } from "react";
import { motion } from "framer-motion";
import { Wallet, Phone, CreditCard, Check, ArrowRight, Shield, Clock, Car } from "lucide-react";

type PaymentMethod = "unitel" | "multicaixa" | null;
type PaymentStep = "select" | "details" | "confirm" | "success";

const RECENT_TRIPS = [
  { id: 1, from: "Viana", to: "Mutamba", driver: "João M.", price: "250 Kz", date: "Hoje, 08:30" },
  { id: 2, from: "Cacuaco", to: "Maianga", driver: "Pedro S.", price: "300 Kz", date: "Hoje, 07:15" },
  { id: 3, from: "Cazenga", to: "Cidade Alta", driver: "Manuel A.", price: "200 Kz", date: "Ontem, 17:45" },
];

const PagamentoPage = () => {
  const [method, setMethod] = useState<PaymentMethod>(null);
  const [step, setStep] = useState<PaymentStep>("select");
  const [amount, setAmount] = useState("");
  const [phone, setPhone] = useState("");
  const [driverPhone, setDriverPhone] = useState("");
  const [selectedTrip, setSelectedTrip] = useState<number | null>(null);

  const handleSelectTrip = (trip: typeof RECENT_TRIPS[0]) => {
    setSelectedTrip(trip.id);
    setAmount(trip.price.replace(" Kz", ""));
  };

  const handleProceed = () => {
    if (step === "select" && method) {
      setStep("details");
    } else if (step === "details" && phone && amount) {
      setStep("confirm");
    } else if (step === "confirm") {
      setStep("success");
    }
  };

  const handleReset = () => {
    setMethod(null);
    setStep("select");
    setAmount("");
    setPhone("");
    setDriverPhone("");
    setSelectedTrip(null);
  };

  if (step === "success") {
    return (
      <div className="container py-20 text-center">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
          <div className="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-4">
            <Check className="h-10 w-10 text-success" />
          </div>
          <h2 className="font-display font-bold text-2xl text-foreground mb-2">Pagamento Enviado!</h2>
          <p className="text-muted-foreground text-sm mb-2">
            {method === "unitel" ? "Unitel Money" : "Multicaixa Express"}
          </p>
          <p className="text-3xl font-display font-bold text-foreground mb-1">{amount} Kz</p>
          <p className="text-sm text-muted-foreground mb-6">
            Verifique a confirmação no seu telefone e aprove o pagamento.
          </p>
          <div className="p-4 rounded-xl bg-card border border-border max-w-xs mx-auto mb-6">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <Shield className="h-3 w-3 text-success" />
              Transacção segura
            </div>
            <p className="text-xs text-muted-foreground">
              O taxista receberá o pagamento assim que confirmar no seu telefone.
            </p>
          </div>
          <button
            onClick={handleReset}
            className="gradient-primary text-primary-foreground px-6 py-2.5 rounded-lg text-sm font-semibold"
          >
            Novo Pagamento
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="container py-6">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="font-display font-bold text-2xl text-foreground mb-1 flex items-center gap-2">
          <Wallet className="h-6 w-6 text-primary" />
          Pagamento
        </h1>
        <p className="text-muted-foreground text-sm mb-6">
          Pague a sua viagem por Unitel Money ou Multicaixa Express
        </p>
      </motion.div>

      {/* Steps indicator */}
      <div className="flex items-center gap-2 mb-6">
        {["Método", "Detalhes", "Confirmar"].map((label, i) => {
          const stepIndex = ["select", "details", "confirm"].indexOf(step);
          const isActive = i <= stepIndex;
          return (
            <div key={label} className="flex items-center gap-2 flex-1">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${isActive ? "gradient-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                {i + 1}
              </div>
              <span className={`text-xs font-medium hidden sm:block ${isActive ? "text-foreground" : "text-muted-foreground"}`}>{label}</span>
              {i < 2 && <div className={`flex-1 h-0.5 ${i < stepIndex ? "bg-primary" : "bg-border"}`} />}
            </div>
          );
        })}
      </div>

      {/* Step 1: Select method */}
      {step === "select" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <button
              onClick={() => setMethod("unitel")}
              className={`p-5 rounded-xl border-2 transition-all text-left ${
                method === "unitel"
                  ? "border-primary bg-accent taxi-shadow"
                  : "border-border bg-card hover:border-primary/30"
              }`}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center">
                  <Phone className="h-6 w-6 text-destructive" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-foreground">Unitel Money</h3>
                  <p className="text-xs text-muted-foreground">Pagamento por telemóvel</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Pague directamente do saldo Unitel Money. Rápido e seguro.
              </p>
            </button>

            <button
              onClick={() => setMethod("multicaixa")}
              className={`p-5 rounded-xl border-2 transition-all text-left ${
                method === "multicaixa"
                  ? "border-primary bg-accent taxi-shadow"
                  : "border-border bg-card hover:border-primary/30"
              }`}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <CreditCard className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-foreground">Multicaixa Express</h3>
                  <p className="text-xs text-muted-foreground">Pagamento por app bancária</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Use o Multicaixa Express para pagar da sua conta bancária.
              </p>
            </button>
          </div>

          {/* Recent trips to pay */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Viagens Recentes</p>
            <div className="space-y-2">
              {RECENT_TRIPS.map((trip) => (
                <button
                  key={trip.id}
                  onClick={() => handleSelectTrip(trip)}
                  className={`w-full p-3 rounded-xl border text-left transition-all ${
                    selectedTrip === trip.id
                      ? "border-primary bg-accent"
                      : "border-border bg-card hover:border-primary/20"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full gradient-primary flex items-center justify-center">
                        <Car className="h-4 w-4 text-primary-foreground" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">{trip.from} → {trip.to}</p>
                        <p className="text-[10px] text-muted-foreground">{trip.driver} • {trip.date}</p>
                      </div>
                    </div>
                    <span className="text-sm font-bold text-foreground">{trip.price}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleProceed}
            disabled={!method}
            className={`w-full py-3 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-opacity ${
              method
                ? "gradient-primary text-primary-foreground"
                : "bg-muted text-muted-foreground cursor-not-allowed"
            }`}
          >
            Continuar <ArrowRight className="h-4 w-4" />
          </button>
        </motion.div>
      )}

      {/* Step 2: Details */}
      {step === "details" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-md mx-auto space-y-4">
          <button onClick={() => setStep("select")} className="text-sm text-primary hover:underline">← Voltar</button>

          <div className="p-5 rounded-xl bg-card border border-border space-y-4">
            <div className="flex items-center gap-3 mb-2">
              {method === "unitel" ? (
                <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center">
                  <Phone className="h-5 w-5 text-destructive" />
                </div>
              ) : (
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <CreditCard className="h-5 w-5 text-primary" />
                </div>
              )}
              <h2 className="font-display font-semibold text-foreground">
                {method === "unitel" ? "Unitel Money" : "Multicaixa Express"}
              </h2>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">O seu número de telefone</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <input
                    type="tel"
                    placeholder={method === "unitel" ? "9XX XXX XXX (Unitel)" : "9XX XXX XXX"}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Número do taxista (para enviar)</label>
                <div className="relative">
                  <Car className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <input
                    type="tel"
                    placeholder="Número do taxista"
                    value={driverPhone}
                    onChange={(e) => setDriverPhone(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-sm border border-border"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Valor a pagar (Kz)</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-muted-foreground">Kz</span>
                  <input
                    type="number"
                    placeholder="0"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 rounded-lg bg-muted text-foreground placeholder:text-muted-foreground text-lg font-bold border border-border text-center"
                  />
                </div>
              </div>

              {/* Quick amounts */}
              <div>
                <p className="text-xs text-muted-foreground mb-2">Valores rápidos</p>
                <div className="flex gap-2 flex-wrap">
                  {["100", "150", "200", "250", "300", "500"].map((val) => (
                    <button
                      key={val}
                      onClick={() => setAmount(val)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                        amount === val
                          ? "gradient-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground border border-border hover:border-primary/30"
                      }`}
                    >
                      {val} Kz
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={handleProceed}
              disabled={!phone || !amount}
              className={`w-full py-3 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 ${
                phone && amount
                  ? "gradient-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground cursor-not-allowed"
              }`}
            >
              Continuar <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </motion.div>
      )}

      {/* Step 3: Confirm */}
      {step === "confirm" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-md mx-auto space-y-4">
          <button onClick={() => setStep("details")} className="text-sm text-primary hover:underline">← Voltar</button>

          <div className="p-5 rounded-xl bg-card border border-border space-y-4">
            <h2 className="font-display font-semibold text-foreground text-center">Confirmar Pagamento</h2>

            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground mb-1">Valor a pagar</p>
              <p className="text-4xl font-display font-bold text-foreground">{amount} Kz</p>
            </div>

            <div className="p-4 rounded-lg bg-muted space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Método</span>
                <span className="font-medium text-foreground">
                  {method === "unitel" ? "Unitel Money" : "Multicaixa Express"}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Seu número</span>
                <span className="font-medium text-foreground">{phone}</span>
              </div>
              {driverPhone && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Taxista</span>
                  <span className="font-medium text-foreground">{driverPhone}</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 p-3 rounded-lg bg-accent text-xs text-accent-foreground">
              <Shield className="h-4 w-4 shrink-0" />
              <p>Será enviado um pedido de confirmação para o seu telefone. Aprove para concluir.</p>
            </div>

            <button
              onClick={handleProceed}
              className="w-full gradient-gold text-secondary-foreground py-3 rounded-lg text-sm font-bold flex items-center justify-center gap-2"
            >
              <Wallet className="h-4 w-4" />
              Pagar {amount} Kz
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default PagamentoPage;
