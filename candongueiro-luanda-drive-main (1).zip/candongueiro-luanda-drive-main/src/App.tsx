import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import AppLayout from "./components/AppLayout";
import HomePage from "./pages/HomePage";
import RotasPage from "./pages/RotasPage";
import AlertasPage from "./pages/AlertasPage";
import AluguerPage from "./pages/AluguerPage";
import CadastroPage from "./pages/CadastroPage";
import PagamentoPage from "./pages/PagamentoPage";
import ComunidadePage from "./pages/ComunidadePage";
import PublicidadePage from "./pages/PublicidadePage";
import AoVivoPage from "./pages/AoVivoPage";
import GruposPage from "./pages/GruposPage";
import AuthPage from "./pages/AuthPage";
import { AuthProvider } from "./hooks/useAuth";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
        <AppLayout>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/rotas" element={<RotasPage />} />
            <Route path="/alertas" element={<AlertasPage />} />
            <Route path="/aluguer" element={<AluguerPage />} />
            <Route path="/cadastro" element={<CadastroPage />} />
            <Route path="/pagamento" element={<PagamentoPage />} />
            <Route path="/comunidade" element={<ComunidadePage />} />
            <Route path="/publicidade" element={<PublicidadePage />} />
            <Route path="/ao-vivo" element={<AoVivoPage />} />
            <Route path="/grupos" element={<GruposPage />} />
            <Route path="/auth" element={<AuthPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AppLayout>
      </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
