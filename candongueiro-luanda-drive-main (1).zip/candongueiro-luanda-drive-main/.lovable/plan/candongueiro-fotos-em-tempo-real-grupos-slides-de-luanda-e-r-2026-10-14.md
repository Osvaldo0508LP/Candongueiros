# CANDONGUEIRO — Fotos em tempo real, Grupos, Slides de Luanda e Rotas com IA

Para funcionar de verdade (tempo real, partilhado entre todos os utilizadores), será activado o **Lovable Cloud** (base de dados, fotos, login e IA).

## 1. Fotos da Via em Tempo Real (nova página "Ao Vivo")
- Taxistas e passageiros publicam foto + localização + tipo de problema (trânsito, operação, obstrução, acidente, estrada boa).
- Feed actualiza sozinho para todos, sem recarregar.
- Botões "Confirmo" / "Já não está" para validar a informação; publicações antigas (mais de 3h) saem do feed.

## 2. Gestão de Grupos (dentro da Comunidade)
**Taxistas e passageiros — grupos de apoio/anúncio:**
- Tipos: Vaquinha (com meta em Kz e barra de progresso, contribuição via Unitel Money/Multicaixa), Primeira viagem grátis, Greve, Aviso geral.
- O administrador do grupo gere membros (aceitar, remover, promover a admin) e publicações.
- Anúncios de greve: o administrador pode enviar o anúncio para a área de Publicidade (aparece no banner do Início).

**Passageiros — grupos de viagem colectiva:**
- Criar grupo com destino, zona de partida, data/hora e número de lugares (mínimo 14).
- Quando o grupo enche, é publicado no "Mural dos Taxistas".
- Taxistas vêem os pedidos, fazem proposta de preço e contactam (chat / WhatsApp); o admin aceita a proposta.

## 3. Slides de Luanda
- Carrossel automático no Início com fotos da cidade (Marginal, Fortaleza, Ilha, Mausoléu, Baía, Kilamba, etc.).
- Imagens públicas de Luanda (Wikimedia Commons, livres de uso), com legenda e autor.
- Nota: ligação directa ao Google Imagens não é permitida pelos termos do Google; usamos um repositório público equivalente.

## 4. Rotas Recomendadas por IA
- Na página Rotas, botão "Analisar com IA": a IA lê os alertas e fotos recentes e indica, para cada rota popular, o estado (Fluido / Lento / Evitar), o motivo e a alternativa sugerida.
- Para taxistas: lista "Onde trabalhar agora" — as rotas onde o trânsito flui e há procura.
- Análise actualizada a cada pedido, com base nos reportes das últimas horas.

## 5. Login
- Login simples (email; Google opcional) necessário para publicar fotos, criar grupos e fazer propostas. Ver o feed não exige login.

## Detalhes técnicos
- Tabelas: profiles (tipo taxista/passageiro), road_reports (+ storage bucket público para fotos, realtime), report_votes, groups (kind: support/vaquinha/free_ride/strike/notice/ride_pool), group_members (role admin/member), group_posts, ride_pool_offers, promoted_announcements. RLS por auth.uid(); papéis de grupo verificados via função security definer.
- Realtime do Supabase em road_reports, group_posts e ride_pool_offers.
- Edge function `analyze-routes` usando o Lovable AI Gateway (modelo padrão, saída JSON com schema estrito, streaming).
- Alertas existentes passam a gravar na base de dados em vez de memória local.
