# Concluir integrações pendentes do CANDONGUEIRO

## O que vai ficar a funcionar
1. **Menu e navegação**: novas páginas "Via Ao Vivo" (fotos em tempo real) e "Grupos" (vaquinhas, greves, viagens colectivas de 14+) no menu de cima e de baixo, mais a página de Entrar/Registar.
2. **Início**: carrossel de slides com imagens de Luanda (fotos livres da internet) acima dos destaques.
3. **Rotas**: secção "Recomendação IA" que analisa os relatos recentes da Via Ao Vivo e sugere as melhores rotas para os taxistas.
4. **Anúncios**: avisos de grupos (greves, vaquinhas, primeira viagem grátis) publicados pelo administrador aparecem no banner de anúncios do Início.
5. **Alertas**: alertas com fotos ficam gravados e visíveis para todos.
6. **Verificação**: testar no navegador o login, publicar um relato com foto, criar grupo e pedir a recomendação IA.

## Detalhes técnicos
- `App.tsx`: rotas `/ao-vivo`, `/grupos`, `/auth`; `AuthProvider` envolve a app.
- `AppLayout.tsx`: novos itens no menu; barra inferior com rolagem horizontal (muitos itens).
- `HomePage.tsx`: incluir `LuandaSlides`; `AdBanner.tsx` lê anúncios de grupos marcados para publicidade.
- `RotasPage.tsx`: incluir `AiRoutes` (chama a função `analyze-routes`).
- Alertas: guardar em `live_reports` (ou tabela própria) com fotos no armazenamento; rever regras de acesso.
- Verificar registos de erros após as alterações.
